//==================================================================================================
//
//  File: main.js
//
//  Description:  Main javascript entry point.   
//                Contains main menu logic and misc support functions.
//
//==================================================================================================

var isRegistered 				= true;
var myModel                     = null;
var mySn                        = null;
var mySku                       = "";


const   UNII_TRY_COUNTER_MAX    = 45;


const   PROG_MODE_MAIN          = 100;
const   PROG_MODE_DOWNLOAD      = 200;
const   PROG_MODE_DOWNLOAD_AUTO = 201;      // Same as DOWNLOAD but no user button presses.
const   PROG_MODE_TECH          = 300;
const   PROG_MODE_SETTINGS      = 400;
const   PROG_MODE_REGISTRATION  = 500;
const   NUM_CHANNELS            = 4;
const   BOOST_TOO_CLOSE         = -1;
const   BOOST_TOO_FAR           = 10;
const	PROG_MODE_ADVANCED		= 600;


var bPrepLocalInfo              = false;
var bUniiUp                     = false;
var uMainLoopCounter            = 0;
var uStateCounter               = 0;
var uRemoteStateCounter         = 0;
var MainLoopIntervalHandle      = null;
var MainLoopTimeoutHandle       = null;
var bMainLoopTimeout            = false;
var MainLoopMs                  = 0; 
var uRegLockStateCounter        = 0;
var uSasKeyCounter              = 0;

var bGotUserInfoRspFromCloud    = false;
var bPrivacyViewed              = false;
var bCheckSouthBoundIfOnStartup = true;
var bSpinner                    = false;
var checkUniiStatusMainTimer    = null;
var bCnxToCu                    = true;             // Set to true if connected locally to CU after reading local BoardConfig.
var bCnxToOneBoxNu              = false;            // Set to true if connected to a 1-Box NU, all UART redirects are disabled.

var bGotRegLockStatus           = false;
var bForceSwUpdate              = false;
var bCloudTalk                  = false;
var bRegisterAsNew              = false;

var iOSPlatform                 = "iOS";
var androidPlatform             = "Android";
var pcBrowserPlatform           = "PcBrowser";
var szNoBoosterCnxMsg           = "This functionality is not available until you reconnect to your booster.";
var isNxtyStatusCurrentMain     = false;


// V1 old PIC additions
var v1GatheringMainData         = false;



var uIcd                    = 0;
var swVerBtScan             = "--.--";          // Filled in by scan results. 
var szVerApp                = "01.07.40";       // In BCD, remember config.xml as well.


// Determine which messages get sent to the console.  1 normal, 10 verbose.
// Level  1: Flow and errors.
// Level  2: Raw bluetooth Tx data
// Level  3: Raw bluetooth Rx Data partial msgs
// Level  4: Timing loops
// Level 10: Bluetooth processing.
// Level 99: Error, print in red.

var PrintLogLevel = 3;
var softwareVersionFlag = false;







//.................................................................................................
function StartMainLoop( loopTime )
{
    if( MainLoopMs != loopTime )
    {
        PrintLog(1, "StartMainLoop(" + loopTime + ")" );        
        if( MainLoopIntervalHandle != null )
        {
            StopMainLoop();
        }
    
        MainLoopIntervalHandle = setInterval(app.mainLoop, loopTime );
        MainLoopMs = loopTime;
    }
}


//.................................................................................................
function StopMainLoop()
{
//    PrintLog(1, "StopDownloadLoop()" );
    clearInterval(MainLoopIntervalHandle)
    MainLoopIntervalHandle = null;
    MainLoopMs = 0;
}


//.................................................................................................
function TimeoutMainLoop()
{
    MainLoopTimeoutHandle = null; 
    bMainLoopTimeout      = true;
}

// RequestModeChange............................................................................................
function RequestModeChange(newMode)
{
    if( newMode == PROG_MODE_MAIN )
    {
        PrintLog(1, "RequestModeChange(MAIN) -----------------------------------------------------------------");
        
        HandleBackKey();
    }
    else if( newMode == PROG_MODE_REGISTRATION )
    {
        PrintLog(1, "RequestModeChange(REGISTRATION) -----------------------------------------------------------------");
        mainScreenSelectedTab = "";
        // Handle if button is displayed...
        //if( guiButtonRegHtml.length > 10 )
        //{
            StopMainLoop();            
            if( isSouthBoundIfCnx && bUniiUp )
            {
                StopGatheringTechData();
//                clearTimeout(checkUniiStatusMainTimer);
//                SendCloudPoll();
//                setTimeout(reg.renderRegView, 300);
                reg.renderRegView();
            }
            else
            {
                if( isSouthBoundIfCnx == false )
                {
                    ShowAlertPopUpMsg(szSouthBoundIfNotCnxMsg, szNoBoosterCnxMsg);
                }
                else
                {
                    ShowAlertPopUpMsg(GetLangString('WirelessLinkDown'), GetLangString('RegModeNotAllowed'));
                }
            }
       // }   // if button is displayed
    }
    else if( newMode == PROG_MODE_TECH )
    {
        PrintLog(1, "RequestModeChange(TECH) -----------------------------------------------------------------");
    
    
        // Handle if button is displayed...
//        if( guiButtonTkHtml.length > 10 )
        {
            StopMainLoop();            
                        
            if( isSouthBoundIfCnx )
            {
//                clearTimeout(checkUniiStatusMainTimer);
//                setTimeout(tech.renderTechView, 300);
                tech.renderTechView();
            }
            else
            {
                ShowAlertPopUpMsg(szSouthBoundIfNotCnxMsg, szNoBoosterCnxMsg);
            }
        }   // if button is displayed...
    }
    else if( newMode == PROG_MODE_ADVANCED )
    {
        PrintLog(1, "RequestModeChange(ADVANCED) -----------------------------------------------------------------");
        
        // Handle if button is displayed...
//        if( guiButtonTkHtml.length > 10 )
        {
            StopMainLoop();            
                        
            if( isSouthBoundIfCnx )
            {
//                clearTimeout(checkUniiStatusMainTimer);
//                setTimeout(advncd.renderAdvancedView, 300);
                advncd.renderAdvancedView();
            }
            else
            {
                ShowAlertPopUpMsg(szSouthBoundIfNotCnxMsg, szNoBoosterCnxMsg);
            }
        }   // if button is displayed...
        
    }
    else if( newMode == PROG_MODE_SETTINGS )
    {
        PrintLog(1, "RequestModeChange(SETTINGS) -----------------------------------------------------------------");

        // Handle if button is displayed...
        //if( (guiAntennaFlag == true) || (guiBoosterFlag == true) )
        //{
            StopMainLoop();            
           
            //if( isSouthBoundIfCnx && bUniiUp )
            //{
                StopGatheringTechData();
//                clearTimeout(checkUniiStatusMainTimer);
//                setTimeout(Stg.renderSettingsView, 300);
                Stg.renderSettingsView();
            //}
            //else
            //{
            //}
        //}   // If button is displayed
    }
    else if( newMode == PROG_MODE_DOWNLOAD )
    {
        PrintLog(1, "RequestModeChange(DOWNLOAD) -----------------------------------------------------------------");

        // Handle if button is displayed...
//        if( guiButtonSwHtml.length > 10 )
        {
            StopMainLoop();            
        
            if( isSouthBoundIfCnx )
            {
                StopGatheringTechData();
                StopSettingsLoop();
                
//                clearTimeout(checkUniiStatusMainTimer);
                Dld.renderDldView();  
            }
            else
            {
                ShowAlertPopUpMsg(szSouthBoundIfNotCnxMsg, szNoBoosterCnxMsg );
            }
        } // if button is displayed...            
        
    }
    else if( newMode == PROG_MODE_DOWNLOAD_AUTO )
    {
        {
            PrintLog(1, "RequestModeChange(DOWNLOAD_AUTO) -----------------------------------------------------------------");
            StopMainLoop();            
        
            if( isSouthBoundIfCnx )
            {
                StopGatheringTechData();
//                clearTimeout(checkUniiStatusMainTimer);
                bDldAutoMode = true;
                Dld.renderDldView();  
            }
            else
            {
                ShowAlertPopUpMsg(szSouthBoundIfNotCnxMsg, szNoBoosterCnxMsg );
            }
        } // if button is displayed...            
        
    }
    else
    {
        PrintLog(99, "RequestModeChange(unknown)=" + newMode );
    }
    
}


// HandleBackKey............................................................................................
function HandleBackKey()
{
    
    if( guiCurrentMode == PROG_MODE_MAIN )
    {
        // Android:  Go to background mode.  No longer ask to exit app...
        navigator.app.exitApp()
    }
    else if( guiCurrentMode == PROG_MODE_REGISTRATION )
    {
        reg.handleBackKey();
    }
    else if( guiCurrentMode == PROG_MODE_TECH )
    {
        tech.handleBackKey();
    }
    else if( guiCurrentMode == PROG_MODE_SETTINGS )
    {
        Stg.handleBackKey();
		window.history.back()
		navigator.app.backHistory();
		history.go(-1);
    }
    else if( (guiCurrentMode == PROG_MODE_DOWNLOAD) || (guiCurrentMode == PROG_MODE_DOWNLOAD_AUTO)  )
    {
        Dld.handleBackKey();
    }
    else if( guiCurrentMode == PROG_MODE_ADVANCED )
    {
    	advncd.handleBackKey();
    }
    else
    {
        ShowAlertPopUpMsg(GetLangString('Back'), GetLangString('BackToWhere'));
    }
}




// PrintLog............................................................................................
function PrintLog(level, txt)
{
    var d       = new Date();
    var myMs    = d.getMilliseconds();
    
    
    if( myMs < 10 )
    {
        myMs = "00" + myMs;
    }
    else if( myMs < 100 )
    {
        myMs = "0" + myMs;
    }
    
    
    if( level == 99 )
    {
//        console.log("**** Error: (" + d.getSeconds() + "." + d.getMilliseconds() + ") " + txt);
        var logText = "(" + d.getMinutes() + ":" + d.getSeconds() + "." + myMs + ") **** Error: " + txt;
        console.log( logText );
        WriteLogFile( logText );
        
//jdo        console.error(txt);            // console.error does not work on phonegap
    }
    else if( level <= PrintLogLevel )
    { 
        var logText = "(" + d.getMinutes() + ":" + d.getSeconds() + "." + myMs + ") " + txt;
        console.log( logText );
        WriteLogFile( logText );
    }
    
}



// HandleButtonDown............................................................................................
function HandleButtonDown()
{
    // No transparency when pressed...
    $(this).css("opacity","1.0");
    $(this).css("outline", "none" );       // Used to remove orange box for android 4+
}

// HandleButtonUp............................................................................................
function HandleButtonUp()
{
    $(this).css("opacity","0.5");
    $(this).css("outline", "none" );       // Used to remove orange box for android 4+
}


//.................................................................................................................
function FindMyCelfi()
{
    if( nxtyRxStatusIcd <= V1_ICD )
    {
        PrintLog(1, "FindMyCelfi called but not allowed for V1_ICD, i.e. old PIC");
    }
    else
    {
        PrintLog(1, "FindMyCelfi called");
        
        // If some message is pending then schedule a come back...
        if( isNxtyMsgPending() == true )
        {
            setTimeout( FindMyCelfi, 130 );
        }
        else
        {
            WriteAddrReq( NXTY_PCCTRL_CLOUD_INFO, CLOUD_INFO_FLASH_LEDS_CMD );
        }
    }
}



// UpdateUniiIcon....................................................................................
function UpdateUniiIcon(bStatus)
{
    if( bCnxToOneBoxNu == false )
    {
        bUniiUp          = bStatus;
    }
}


// CheckUniiStatusMain....................................................................................
function CheckUniiStatusMain()
{
    var u8Buff  = new Uint8Array(20);
 
    if( guiCurrentMode == PROG_MODE_MAIN )
    {
        // Check to see if UNII is up...
        GetNxtySuperMsgLinkStatus();
    
        // Return here in x seconds....
        checkUniiStatusMainTimer = setTimeout(CheckUniiStatusMain, 5000);
    }
}




// U8ToHexText............................................................................................
function U8ToHexText(u8)
{
    if( u8 < 0x10 )
    {
        return( "0" + u8.toString(16).toUpperCase() );     // Add a leading 0....
    }
    else
    {
        return( u8.toString(16).toUpperCase() );     
    }
}

// DecTo3Text............................................................................................
function DecTo3Text(u8)
{
    if( u8 < 10 )
    {
        return( "00" + u8.toString(10) );     // Add a leading 00....
    }
    else if( u8 < 100 )
    {
        return( "0" + u8.toString(10) );     // Add a leading 0....
    }

    else
    {
        return( u8.toString(10) );     
    }
}

// HexTo3Text.....................................................................................................
function HexTo3Text(myNum) 
{
    if(myNum < 0x010) 
    {
        return( "00" + myNum.toString(16).toUpperCase() );
    } 
    else if(myNum < 0x100) 
    {
        return( "0" + myNum.toString(16).toUpperCase() );
    } 
    else 
    {
        return( myNum.toString(16).toUpperCase() );
    }
}

// UpdateRegIcon....................................................................................
function UpdateRegIcon(reg)
{
    if(reg == 1)
    {
        // Set to Registered...
        isRegistered = true;
    }
    else
    {
        // Set to NOT Registered...
        isRegistered = false;
    }
}









// HandleOsConfirmation.......................................................................................
function HandleOsConfirmation(buttonIndex) 
{
    // buttonIndex = 0 if dialog dismissed, i.e. back button pressed.
    // buttonIndex = 1 if 'Ok'
    if( buttonIndex == 1 )
    {
        // Do nothing since we no longer want to kill the app.  This will force the user to manually kill.
        // Ok...Exit...Kill the app...
//        navigator.app.exitApp();                
    }
}



// HandleSwUpdateConfirmation.......................................................................................
function HandleSwUpdateConfirmation(buttonIndex) 
{
    // buttonIndex = 0 if dialog dismissed, i.e. back button pressed.
    // buttonIndex = 1 if 'Ok'
    if( (buttonIndex == 0) || (buttonIndex == 1) )
    {
        // Go to the software download page...
        Dld.renderDldView(); 
    }
}

// HandlePrivacyConfirmation.......................................................................................
function HandlePrivacyConfirmation(buttonIndex) 
{
    // buttonIndex = 0 if dialog dismissed, i.e. back button pressed.
    // buttonIndex = 1 if 'Ok'
    if( buttonIndex == 0 )
    {
        // If they dismiss, then give it to them again....
        ShowConfirmPopUpMsg( "KEY_PRIVACY_POLICY",                // title
            "",                                                 // message text not used, filled in by handler...
            HandlePrivacyConfirmation,                          // callback to invoke with index of button pressed
            ['Ok'] );                                           // buttonLabels

        UpdateStatusLine("Please select Ok..."); 
    }
    else if( (buttonIndex == 1) || (buttonIndex == 2) )
    {
        // Ok...
        bPrivacyViewed = true;
        
        if( buttonIndex == 1 )
        {
/*        
            if( (isSouthBoundIfCnx == false) && (guiDeviceFlag == false) )
            {
                // Start the spinner..if BT not connected and we are not asking the user to select a BT device.
                ShowWaitPopUpMsg( GetLangString("PleaseWait"), GetLangString("SearchingDevices") );
                UpdateStatusLine("Searching for Cel-Fi devices...");
            }
*/            
        }
        
    }
}

// HandleUniiRetry.......................................................................................
// process the confirmation dialog result
function HandleUniiRetry(buttonIndex) 
{
    // buttonIndex = 0 if dialog dismissed, i.e. back button pressed.
    // buttonIndex = 1 if 'Retry' try again.
    // buttonIndex = 2 if 'Exit'
    if( buttonIndex == 1 )
    {
        // Retry...
    	document.getElementById("searchMessageBox").innerHTML = GetLangString('Retrying');
    	StartMainLoop(1000);
        nxtySwVerNuCf          = null;
//        nxtySwVerCuCf          = null;      // Set to Null so new NU version gets sent to cloud.  Bug 1324
//        bUniiUp                = true;
    }
    
    
}

// HandleCloudRetry.......................................................................................
// process the confirmation dialog result
function HandleCloudRetry(buttonIndex) 
{
    // buttonIndex = 0 if dialog dismissed, i.e. back button pressed.
    // buttonIndex = 1 if 'Retry' try again.
    // buttonIndex = 2 if 'Exit'
    if( buttonIndex == 1 )
    {
        // MAIN is only first pass through the MAIN loop when screen is showing Syncing.
        if( guiCurrentMode == PROG_MODE_MAIN )
        {
            // Retry...
        	document.getElementById("searchMessageBox").innerHTML = GetLangString('Retrying');
            StartMainLoop(1000);
        }
                    
        // See if we have a network connection, i.e. WiFi or Cell.
        isNetworkConnected = NorthBoundConnectionActive();
    }
    
    
}




            
            
            
//-----------------------------------------------------------------------------------
//  
//   Returns an array of bytes representing the ASCII equivalent of the string.
//
//      var u8rsp;
//      var temp  = "regOpForce:true";
//      u8rsp = stringToBytes(temp);
//
//      var outText = u8rsp[0].toString(16);    // Convert to hex output...
//      for( var i = 1; i < u8rsp.length; i++ )
//      {
//          outText = outText + " " + u8rsp[i].toString(16);
//      }
//      PrintLog(1,"          stringToBytes: " + outText );     --> stringToBytes: 72 65 67 4f 70 46 6f 72 63 65 3a 74 72 75 65
//
//
function stringToBytes(inString)
{
    var rtnBytes = [];

    for( var i = 0; i < inString.length; ++i ) 
    {
        rtnBytes.push(inString.charCodeAt(i));
    }
    
    return(rtnBytes);
}


//-----------------------------------------------------------------------------------
//
//
function bytesToString(array) 
{
    var rtnString = "";
  
    for( var i = 0; i < array.length; i++ ) 
    {
        rtnString += String.fromCharCode(array[i]);
        
        // See if we have found the terminating null.
        if( array[i] == 0 )
        {
            break;
        }
    }
    return rtnString;
}

//..................................................................................
function WaitForFileSystemThenStartSouthboundIf()
{ 
    if(bfileOpenLogFileSuccess)
    {
        // Now that the file system is open, start SouthBound Interface...
        OpenSouthBoundIf();
    }
    else
    {
        // Try again in one second...
        setTimeout(WaitForFileSystemThenStartSouthboundIf, 1000);  
    }
}


// ..................................................................................
var app = {
     
    // deviceready Event Handler
    //
    // PhoneGap is now loaded and it is now safe to make calls using PhoneGap
    //
    onDeviceReadyAfterSplash: function() {

/*
        if( window.device.platform != iOSPlatform )
        {
            // IOS did not like opening the file system this early, no error just stalled.
            OpenFileSystem();
    
            PrintLog(10,  "device ready:  Running on phone version: " + window.device.version + " parseFloat:" + parseFloat(window.device.version) );
        }
*/

        
        isNxtyStatusCurrent = false;
        isNxtySnCurrent     = false;

        // Register the event listener if the back button is pressed...
        // This is not part of the GUI but the Android's hardware back button...
        document.addEventListener("backbutton", HandleBackKey, false);
        
        app.renderHomeView();
        
        // Start the GUI...
        StartGuiInterface();
       
        OpenFileSystem();
        
        // Only start bluetooth if on a phone...
        if( window.device.platform == iOSPlatform )
        {
//            OpenFileSystem();
        
            if (parseFloat(window.device.version) >= 7.0) 
            {
                StatusBar.hide();
            }
            
        } 
        
        WaitForFileSystemThenStartSouthboundIf();
        //setTimeout(function(){OpenSouthBoundIf();util.showSearchAnimation();}, 1000 );
               
    },   
       
       












    
    


    renderHomeView: function() 
    {
        PrintLog(1, "RenderHomeView()...");
    
        
        uMainLoopCounter = 0;

        // if Phone, Check the OS version.
        // Android must be >= 4.4.2 for WebSocket and Bluetooth LE plugin
        // IOS     must be >= 7.1   for WebSocket and Bluetooth LE plugin.
        if(ImRunningOnPhone == true)
        {
            PrintLog(1, "Phone Model: " + window.device.model + "  OS: " + window.device.platform + " Ver: " + window.device.version );
            if( ((window.device.platform == androidPlatform) && (parseFloat(window.device.version) < 4.4))      ||
                ((window.device.platform == iOSPlatform)     && (parseFloat(window.device.version) < 7.1))      )
            {
                PrintLog(1, "Phone's Operating System is out of date.   Please upgrade to latest version." );
                
                ShowConfirmPopUpMsg( "KEY_UPDATE_PHONE_SOFTWARE",       // title
                    "Phone Operating System is out of date.   Please upgrade to latest version.",    // message filled in by handler
                    HandleOsConfirmation,                               // callback to invoke with index of button pressed
                    ['Ok'] );                                           // buttonLabels
            } 
            else
            {
            	softwareVersionFlag = true;
                // Start the handler to be called periodically...
                StartMainLoop(1000);
            } 
        }                
        else
        {
            softwareVersionFlag = true;
            // Start the handler to be called periodically...
            StartMainLoop(1000);
        }
        
        
        

//        PrintLog(1, "Screen density: low=0.75 med=1.0 high=1.5  This screen=" +  window.devicePixelRatio );    
        guiCurrentMode = PROG_MODE_MAIN;
    },


    initializeAfterSplash: function() 
    {
         
        if(ImRunningOnPhone != true)
        {
            PrintLog(10, "running on desktop");
            this.onDeviceReadyAfterSplash();
        }
        else
        {
            PrintLog(10, "running on phone");
            // Call onDeviceReadyAfterSplash when PhoneGap is loaded.
            //
            // At this point, the document has loaded but phonegap-1.0.0.js has not.
            // When PhoneGap is loaded and talking with the native device,
            // it will call the event `deviceready`.
            // 
            document.addEventListener('deviceready', this.onDeviceReadyAfterSplash, false);
        }
    },





    // V2 Main Loop.............................................................................
    mainLoop: function() 
    {
  
        PrintLog(4, "App: Main loop..." );
        if( bCheckSouthBoundIfOnStartup )
        {

            if( isSouthBoundIfStarted == false )
            {
              // Do nothing until interface has started...
              return;
            }
            else
            {
                // Interface is not connected...see if user enabled...
                if( isSouthBoundIfEnabled == false )
                {
                    if( uMainLoopCounter == 0 )
                    {
                        UpdateStatusLine( szSouthBoundIfEnableMsg );
                    }
                    
                    return;
                }
                else
                {
                    
                    
                    // Normal flow should come here once bluetooth has been enabled...
                    bCheckSouthBoundIfOnStartup = false;

                    // Privacy policy...
                    if(window.localStorage.getItem("privacyPolicy")==null)
                    {
                        ShowConfirmPopUpMsg( "KEY_PRIVACY_POLICY",          // title
                            "",                                             // message text not used, filled in by handler
                            HandlePrivacyConfirmation,                      // callback to invoke with index of button pressed
                            ['Ok'] );                                       // buttonLabels
        
                        UpdateStatusLine("Privacy policy..."); 
                    }else{
                    	//buttonIndex = 1;
                    	HandlePrivacyConfirmation(1);
                    }
                    
                    
                    if( CFG_RUN_ON_SANDBOX )
                    {
                        PrintLog(1, "App sw: " + szVerApp + "(S)  Cel-fi BT sw: " + swVerBtScan );
                    }
                    else
                    {
                        PrintLog(1, "App sw: " + szVerApp + "(P)  Cel-fi BT sw: " + swVerBtScan );
                    }
                    
                                       
                }
            }
        }
        
        if( bPrivacyViewed == false )
        {
            return;
        }
        

        // Wait until the BT device has been selected...
        if( isSouthBoundIfListDone == false )
        {
            return;
        }
        
        
        // ------------------------------------------------------------------------------------------
        if( isSouthBoundIfCnx )
        {
            // Start the main loop timer once we get a SouthBound connection and view privacy...
            if( (MainLoopTimeoutHandle == null) && (bMainLoopTimeout == false) )
            {
                MainLoopTimeoutHandle = setTimeout(TimeoutMainLoop, 60000 );     // Set timeout for 1 minute.
                PrintLog(1, "MainLoop: Start 60 sec timeout.")
            }
            
            
            // Get the Status message from the Unit..................................................
            if( isNxtyStatusCurrentMain == false )
            {
                if( uMainLoopCounter == 0 )
                {
                    // Get the status...returns build config for previous versions of the ICD
                    PrintLog(1, "MainLoop: Get status to determine ICD level...Count 0");
                    StartMainLoop(250);
                
                    // See if we have a network connection, i.e. WiFi, Cell or Ethernet.
                    isNetworkConnected = NorthBoundConnectionActive();
 
                    // Start the spinner..
                    util.deviceIdentified();
                    
                    
                    var u8TempBuff  = new Uint8Array(2);
                    u8TempBuff[0] = NXTY_PHONE_ICD_VER;
                    nxty.SendNxtyMsg(NXTY_STATUS_REQ, u8TempBuff, 1);
                }
                else if( uMainLoopCounter == 1 )
                {
                    // Stay here until we get a correct status.  If we get the wrong ICD version we are messed up...
                    if( isNxtyStatusCurrent == false )
                    {
                        // Bump the counter back so when incremented below we come back here.
                        uMainLoopCounter--;
                        
                        // Get the status...returns build config for previous versions of the ICD
                        PrintLog(1, "MainLoop: Get status to determine ICD level...Count 1");
                    
                        var u8TempBuff  = new Uint8Array(2);
                        u8TempBuff[0] = NXTY_PHONE_ICD_VER;
                        nxty.SendNxtyMsg(NXTY_STATUS_REQ, u8TempBuff, 1);
                    }
                    
                }
                else if( uMainLoopCounter == 2 )
                {
                    PrintLog(1, "MainLoop: Get status to determine ICD level...Count 2");

                    // We should have retrieved the ICD version in the BT connection logic.
                    // If old PIC then bypass the V2 messages...
                    if( nxtyRxStatusIcd <= V1_ICD )
                    {
                        uMainLoopCounter = 5;
                    }
                }
                else if( uMainLoopCounter == 3 )
                {
                    PrintLog(1, "MainLoop: Get status to determine ICD level...Count 3");
                
                    // Wait at least 3 seconds after BT connection to make sure any pending NAKs are flushed...
                    // Make sure that whatever we are connected to is local and not redirected.
                    // This command will only work for V2 and higher, for V1 it will be dropped and NAKed.
                    WriteAddrReq( NXTY_PCCTRL_UART_REDIRECT, 0 );
                }
                else if( uMainLoopCounter == 4 )
                {
                    PrintLog(1, "MainLoop: Get status to determine ICD level...Count 4");
                
                    // Tell the Ares code to slow down the debug traffic so Bluetooth is responsive.
                    // This was necessary on the 1-Box otherwise the Tech Mode data would timeout.
                    WriteAddrReq( NXTY_PCCTRL_CLOUD_INFO, CLOUD_INFO_MIN_TRAFFIC_CMD );
                }                
                else if( uMainLoopCounter > 4 )
                {
                    PrintLog(1, "MainLoop: Get status to determine ICD level...Count > 4");
                
                    isNxtyStatusCurrentMain = true;
                    bNxtySuperMsgRsp        = false;
                }
            } 

            // Get the local information from the unit that the BT is attached to, i.e. CU ..............
            else if( bNxtySuperMsgLocalInfo == false )
            {
                PrintLog(1, "MainLoop: Get local info...");
                StartMainLoop(1000);
 

                if( nxtyRxStatusIcd <= V1_ICD )
                {
                    if( v1GatheringMainData == false )
                    {
                        // Start gathering V1 data and set bNxtySuperMsgRsp to true when done.
                        StartV1MainLoop(1000);
                        v1GatheringMainData = true;
                    }
                }                
            
                if( bNxtySuperMsgRsp == false )
                {
                    GetNxtySuperMsgInfo();
                }
                else
                {
                    StartMainLoop(10);      // Speed it up...
                    bNxtySuperMsgLocalInfo = true;
                    bCnxToCu               = (nxtyRxStatusBoardConfig & IM_A_CU_MASK)?true:false;
                    bCnxToOneBoxNu         = (nxtyRxStatusBoardConfig & IM_A_1BOX_NU_MASK)?true:false;
                    
                    // if connected to NU and it is not a OneBox, then do not continue
                    if( (bCnxToCu==false) && (bCnxToOneBoxNu==false) )
                    {
                        StopMainLoop();   
                        ShowAlertPopUpMsg(GetLangString('ConnectedToNu'), ""+GetLangString('UnableToConnectConnectToCU')+"<br>"+GetLangString('PlsCloseApplicationConnectUSB')+"");
                        return;
                    }

 
                    // If on a 1-Box perform some house keeping...
                    if( bCnxToOneBoxNu )
                    {
                        // UNII is always up...
                        bUniiUp = true;
                        UpdateUniiIcon(bUniiUp);
                        
                        // Since Tech mode pulls from the CU cloud buffer set it to the retrieved NU address...
                        nxtyCuCloudBuffAddr = nxtyNuCloudBuffAddr;
                        nxtyCuUniqueId      = nxtyNuUniqueId;
                        
                        // Bug 1553:  Change the SW names from "NU xxx" to just "xxx" and set CU to null.
                        //           ["UnSec Cfg", "NU_ART", "NU_EVM", "NU_PIC", "Sec Cfg", "Bluetooth", "NU_Ares",  "CU_ART", "CU_EVM", "CU_PIC", "CU_Ares"];         // Software image names
                        guiSwNames = ["UnSec Cfg", "ART",    "EVM",    "PIC",    "Sec Cfg", "Bluetooth", "Ares",     "",        "",        "",     ""  ];
                        
                        
                        // Update the CU's build ID to be used on Build ID check below.
                        nxtySwBuildIdCu     = nxtySwBuildIdNu;
                    }

                    bNxtySuperMsgRsp = false;

                }
            }    

            // Get the 2nd Glob of local information from the unit that the BT is attached to, i.e. CU ..............
            else if( bNxtySuperMsgLocalInfo2 == false )
            {

                PrintLog(1, "MainLoop: Get local info 2...");
                if( bNxtySuperMsgRsp == false )
                {
                    GetNxtySuperMsgInfo2();
                    StartMainLoop(1000);                    
                }
                else
                {
                    bNxtySuperMsgLocalInfo2 = true;
                    StartMainLoop(10);      // Speed it up...                    
                }
            }    


            // Prep local info.............................................
            else if( bPrepLocalInfo == false )
            {
                PrintLog(1, "MainLoop: Prep local info...");
                StartMainLoop(1000);
                 
                bPrepLocalInfo  = true;
                guiSerialNumber = mySn;
  
                if( bCnxToOneBoxNu == true )
                {
                    // Get the mode and band parameters for the settings page if this is a 1-Box
                    GetNxtySuperMsgBoosterParams();
                }
                else
                {
                    GetNxtySuperMsgLinkStatus();
                }
                    
                    
                // Prepare to get the remote info...
                InitGetRegLockStatus();
                
                bNxtySuperMsgRsp    = false;
                uStateCounter       = 0;
                uRemoteStateCounter = 0;
            }
            
            // Wait here until the UNII is up...........................................................
            else if( bUniiUp == false )
            {
                PrintLog(1, "MainLoop: Checking Wireless link: " + uStateCounter + " of " + UNII_TRY_COUNTER_MAX ); 
                StartMainLoop(1000);
                uStateCounter++;
                
                if( uStateCounter < UNII_TRY_COUNTER_MAX )
                {
                    GetNxtySuperMsgLinkStatus();
                }
                else
                {
                
                    // Clear the loop timer to stop the loop...
                    StopMainLoop();            
                    StopWaitPopUpMsg();
                    uMainLoopCounter = 0;
                    uStateCounter    = 0;
                
                                        
                    var eText = "Wireless link between the Network Unit and Coverage Unit is down.  Please wait for the link to connect and try again.";
                    UpdateStatusLine( eText + "<br>Cnx: " + myModel + ":" + mySn );            
                    ShowConfirmPopUpMsg( "KEY_WIRELESS_LINK_DOWN",                      // title
                        eText,                                                          // message filled in by handler
                        HandleUniiRetry,                                                // callback to invoke with index of button pressed
                        ['Retry'] );                                                    // buttonLabels
                
                }                    
            }


            // Get info from remote unit...................................................................................
            else if( (bNxtySuperMsgRemoteInfo == false) && (bCnxToOneBoxNu == false) )
            {
                PrintLog(1, "MainLoop: Get info from remote unit..." );
                StartMainLoop(1000);
            
                if( nxtyRxStatusIcd <= V1_ICD )
                {
                    bNxtySuperMsgRemoteInfo = true;
                    uStateCounter    = 0;
  
                    // Since we cannot retrieve the following SW version info for V1 just set to 0.  
                    nxtySwVerNuSCfg = "000.000";
                    nxtySwVerNuUCfg = "000.000";
                    nxtySwVerNuArt  = "000.000";
                    nxtySwVerNuEvm  = "000.000";
                    nxtySwVerCuEvm  = "000.000";

                    // Fall through...                    
                    bNxtySuperMsgRsp     = true;
                    bGotRegLockStatus    = true;
                    guiGotTechModeValues = true;
                }
                else
                {            
   
                    if( IsUartRemote() == false )     
                    {
                        SetUartRemote();
                        uRemoteStateCounter = 1;               
                    }
                    else
                    {
                        // The first time in this portion of the else we want to reset a couple of flags.
                        if( uRemoteStateCounter )
                        {
                            bNxtySuperMsgRsp    = false;
                            uRemoteStateCounter = 0;
                        }
                    
                        // The UART should now be redirected to get remote data...
                        if( bNxtySuperMsgRsp == false )
                        {
                            GetNxtySuperMsgInfo();
                        }
                        else
                        {
                            bNxtySuperMsgRemoteInfo = true;
                            uStateCounter           = 0;
                            bNxtySuperMsgRsp        = false;
                            StartMainLoop(10);      // Speed it up...
                        }
                    }
                }  // End V2
            }

            // Wait until we receive the device key from Azure..........................
            else if( sasDevKey.length == 0 )
            {
                PrintLog(1, "MainLoop: Waiting on the device key from Azure...Sec=" + uSasKeyCounter );
                StartMainLoop(1000);
                
                if( !(uSasKeyCounter%10) )
                {
                    // Call every 10 seconds...
                    RegisterCloudDev(nxtyNuUniqueId);
                }
                uSasKeyCounter++;
            }
            
            else if( bFlushC2d )
            {
                PrintLog(1, "MainLoop: Waiting on Azure C2D flush..." );
            }
            
            // If we have had to register with the cloud, i.e. call SendCloudAssociateSystem() and SendCloudAssociateBoards(), 
            // then wait for the cloud to indicate that it has completed with its housekeeping..................
            else if( (regIotFlag == "U") && (szCloudRegStatus != "OK") )
            {
                PrintLog(1, "MainLoop: Waiting on Azure to complete its internal housekeeping and return with an OK." );
                SendCloudParamGet(WAVE2_PARAMTYPE_REGISTRATION_STATUS, "", "", "");
                StartMainLoop(2000);
            }

            
            // Now that we have the sasDevKey send some data to the cloud...............
            else if( bCloudTalk == false )
            {
                PrintLog(1, "MainLoop: Talk to the cloud..." );
                
                // V1 ICD falls through too fast so only speed up if not V1...
                if( nxtyRxStatusIcd > V1_ICD )
                {                
                    StartMainLoop(10);  // Speed it up...
                }

                bCloudTalk = true;


                // Get SKU, i.e. now the Model Number...
                // First check to see if we have retrieved the SKU previously...                    
                myModel = window.localStorage.getItem(nxtyCuUniqueId);              // returns null if key not found...
                
                if( (myModel != null) && (myModel.length > 15) )        // length should be 20 for new SKU
                {
                    ProcessSku(myModel);
                }
                else
                {
                    // Get the SKU based on the unique ID which is part of the header...
                    SendCloudParamGet(WAVE2_PARAMTYPE_PARTNUMBER, "", "", "");
                }
                
                szOperatorCodeNames = window.localStorage.getItem( "szOperatorCodeNames" );
                
                if( szOperatorCodeNames === null )
                {
                    SendCloudParamGet(WAVE2_PARAMTYPE_OPERATORLISTALL, "", "", "");
                }                          


                
                // Register for push notifications so we can send our regID to the cloud.
                if( window.device.platform == androidPlatform )
                {
                    InitGcmPush();
                    SendCloudParamSet(WAVE2_PARAMTYPE_DEVICETYPE, "Android", "", "", "");  
                }
                else if( window.device.platform == iOSPlatform )
                {
                    InitIosPush();
                    SendCloudParamSet(WAVE2_PARAMTYPE_DEVICETYPE, "IOS", "", "", "");  
                }
                else if (window.device.platform == pcBrowserPlatform)
                {
                    SendCloudParamSet(WAVE2_PARAMTYPE_DEVICETYPE, window.device.PlatformOS, "", "", "");  
                }
                
                // Get the first name if available...
                SendCloudParamGet(WAVE2_PARAMTYPE_FIRSTNAME, "", "", "");
                
                // See if there is a list of operators that we can switch to...
                SendCloudParamGet(WAVE2_PARAMTYPE_OPERATORLIST, "", "", "");
                
                // See if operator config has changed outside of app, i.e. via Redhawk...
                var storedCfgPn = window.localStorage.getItem(nxtyCuUniqueId + "nxtyConfigPn");
                if( storedCfgPn != nxtyConfigPn )
                {
                    PrintLog(1, "MainLoop: Config has changed, get new operator name.  Stored cfg=" + storedCfgPn + " new cfg=" + nxtyConfigPn );
                    window.localStorage.setItem(nxtyCuUniqueId + "nxtyConfigPn", nxtyConfigPn);
                    
                    // Clear the stored operator name and code...
                    window.localStorage.removeItem(nxtyCuUniqueId + "guiOperatorCode", guiOperatorCode);
                    window.localStorage.removeItem(nxtyCuUniqueId + "guiOperator",     guiOperator);                        
                } 
                
                // See if operator code and operator are stored on phone yet...
                guiOperatorCode = window.localStorage.getItem(nxtyCuUniqueId + "guiOperatorCode");
                guiOperator     = window.localStorage.getItem(nxtyCuUniqueId + "guiOperator");
                if( (guiOperatorCode === null) || (guiOperator === null) ) 
                {
                    SendCloudParamGet(WAVE2_PARAMTYPE_OPERATORNAME, nxtyConfigPn, "", "");
                }
                
            }            
            

            // Get the 2nd Glob of information ..............
            else if( (bNxtySuperMsgRemoteInfo2 == false) && (bCnxToOneBoxNu == false) )
            {
                PrintLog(1, "MainLoop: Get info 2 from remote unit..." );
                StartMainLoop(1000);        
                
                if( bNxtySuperMsgRsp == false )
                {
                    GetNxtySuperMsgInfo2();
                }
                else
                {
                    bNxtySuperMsgRemoteInfo2 = true;
                    
                    // V1 ICD falls through too fast so only speed up if not V1...
                    if( nxtyRxStatusIcd > V1_ICD )
                    {
                        StartMainLoop(10);  // Speed it up...
                    }
                }
            }    

            // Get Reg Lock status...........................................................
            else if( bGotRegLockStatus == false )
            {
                PrintLog(1, "MainLoop: Get RegLockStatus..." );
                StartMainLoop(500);  

                // Keep calling until function returns true.
                bGotRegLockStatus = GetRegLockStatus();
            }            
            
            // Bug #1337: Wait here until we gather the Tech Mode data and send to cloud.......................................................................
            else if( (guiGotTechModeValues == false) && (isNetworkConnected == true) )
            {
                PrintLog(1, "MainLoop: Get Tech Mode data..." );
                StartMainLoop(1000);        

                if( bGatheringTechData == false )
                {
                    // Start gathering the tech mode data.............                    
                    StartGatheringTechData();
                    util.gatheringDeviceData();
                    
                    // Also, silently start checking for Software updates...
                    if( guiSoftwareStatus == SW_STATUS_UNKNOWN )
                    {
                        CheckForSoftwareUpdates();
                    }
                    
//                    setInterval(geoTrack, 10000 );
                }
            
            }            
            else 
            {
                PrintLog(1, "MainLoop: Done........" );

                // Clear the loop timer to stop the loop...
                StopMainLoop();            
                StopWaitPopUpMsg();
                uMainLoopCounter = 0;
                clearTimeout(MainLoopTimeoutHandle);
                MainLoopTimeoutHandle = null; 


                if( isNetworkConnected == false )
                {
                    var eText = GetLangString("NoWiFiCellSub1");    // "Unable to connect to cloud, no WiFi or Cell available.";
                    ShowAlertPopUpMsg(GetLangString("NetworkStatus"),  eText);
                    UpdateStatusLine( eText + "<br>Cnx: " + myModel + ":" + mySn );
                    ShowConfirmPopUpMsg( "KEY_NO_WIFI_OR_CELL",         // title
                        eText,                                          // message provided by handler
                        HandleCloudRetry,                               // callback to invoke with index of button pressed
                        ['Retry'] );                                    // buttonLabels                                     
                }
                else
                {

                
                    if( nxtyRxStatusIcd <= V1_ICD )
                    {
                        // If we have a new 590 formatted SKU, i.e. length equal 20, then see if any SW available.
                        if( mySku.length == 20 )
                        {
                            if( guiSoftwareStatus == SW_STATUS_UNKNOWN )
                            {
                                CheckForSoftwareUpdates();
                            }
                        }
                    }                    

                    UpdateStatusLine( "Select button...<br>Cnx: " + myModel + ":" + mySn );                             


                    // Fill in some interface variables...
                    // Version info from the hardware...    should have already been filled in by now...
                    FillSwCelFiVers();

                    // Take a snapshot of where we are...
                    DumpDataTables();

                    var bEvalRegLockBits = true;
                    


                    
                    // See if location lock bit is set... 
                    if( nxtyRxRegLockStatus & 0x01 )
                    { 
                        if( nxtyRegSupportData != null )
                        {
                            // See if we are in cell-search...
                            if( (nxtyRegSupportData & REG_SUPPORT_DATA_TYPE_MASK) == REG_SUPPORT_DATA_TYPE_CELL_SEARCH )
                            {
                                // We are still in cell search so do not evaluate the bits yet.   Must wait for cell search to complete.
                                PrintLog(1, "Location lock bit set and cell search is still in progress.  RegLoc = 0x" + nxtyRxRegLockStatus.toString(16) + "  RegSupportData = 0x" + nxtyRegSupportData.toString(16) );
                                PrintLog(1, "Do not evaluate the RegLock bits until cell search has completed." );
                                bEvalRegLockBits = false;
                                
                                // Start the periodic check for cell-search to complete.   
                                setTimeout( LocationLockLoop, 30000 );
                                
                                // Display the dashboard...
                                RequestModeChange(PROG_MODE_TECH);
                            }
                        }
                    }
                     
                     
                    if( bEvalRegLockBits == true )
                    { 
                        EvalRegLockBits();
                    }

                } 
            }  // End of else


           
          
            uMainLoopCounter++;
            

        }   // End if( isSouthBoundIfCnx )

        
        
        // Timeout processing............................................
        if( bMainLoopTimeout == true )
        {
            // Clear the loop timer to stop the loop...
            StopMainLoop();
            StopV1MainLoop();           // Just in case the V1 loop was running.
            StopWaitPopUpMsg();
            uMainLoopCounter = 0;
            bMainLoopTimeout = false;
            
            var     eTxt                                     = GetLangString("UnableToSyncError99"); // "Move closer to the booster and retry: 99";
            if( isSouthBoundIfCnx == false )
            {
                eTxt = GetLangString("UnableToSyncError02");    // "Unable to sync to the booster: 02";             // Lost BT connection after starting to sync.
            }
            else if( isNxtyStatusCurrent == false )
            {
                eTxt = GetLangString("UnableToSyncError04");    // "Unable to sync to the booster: 04";             // Cannot get status message
            }
            else if( platformName == null )
            {
                eTxt = GetLangString("UnableToSyncError07");    // "Unable to sync to the Wave portal: 07";         // WSS not providing text string.
            }
            else if( (regIotFlag == "U") && (szCloudRegStatus != "OK") )
            {
                eTxt = GetLangString("UnableToSyncError10");    // "Unable to sync to the Wave portal: 10";         // Not able to get the OK from Azure...
            }
            else if( bGotRegLockStatus == false )
            {
                eTxt = GetLangString("UnableToSyncError09");    // "Unable to sync to the booster: 09";             // PIC/Ares mismatch: RegLockStatus
            }
            else
            {
                
                if( (nxtySwVerNuCf  == null)    ||  // eTxt = "Unable to get NU SW Ver from Cel-Fi";
                    (nxtySwVerNuPic == null)    ||  // eTxt = "Unable to get NU PIC SW Ver from Cel-Fi";
                    (nxtyNuUniqueId == null)    )   // eTxt = "Unable to get NU Unique ID from Cel-Fi";
                {
                    eTxt = GetLangString("UnableToSyncError05");    // "Unable to sync to the booster: 05";
                }
                
                if( bCnxToOneBoxNu == false )
                {
                    if( (nxtySwVerCuCf  == null)    || // eTxt = "Unable to get CU SW Ver from Cel-Fi";
                        (nxtySwVerCuPic == null)    || // eTxt = "Unable to get CU PIC SW Ver from Cel-Fi";
                        (nxtySwVerCuBt  == null)    || // eTxt = "Unable to get BT SW Ver from Cel-Fi";
                        (nxtyCuUniqueId == null)    )  // eTxt = "Unable to get CU Unique ID from Cel-Fi";
                    {
                        eTxt = GetLangString("UnableToSyncError05");    // "Unable to sync to the booster: 05";
                    }
                }
            }
                
                            
            ShowConfirmPopUpMsg( "KEY_UNABLE_TO_SYNC",      // title
                    eTxt,                                   // message filled in by handler
                    util.showSearchAnimation,               // callback to invoke with index of button pressed
                    ['Ok'] );  
        }
        
        
    }, // End of MainLoop()

};




// GetProductTypeFromSku...........................................................................................................
function GetProductTypeFromSku(tempSku) 
{ 
    var tempProd = "";

    // sku looks like "590NP34...etc"                    
    if( tempSku.search("P34") == 4 )
    {
        tempProd = PRODUCT_TYPE_PRO;    
    }
    else if( tempSku.search("D32") == 4 )
    {
        tempProd = PRODUCT_TYPE_DUO;    
    }
    else if( tempSku.search("S32") == 4 )
    {
        tempProd = PRODUCT_TYPE_PRIME;    
    }
    else if( tempSku.search("G31") == 4 )
    {
        tempProd = PRODUCT_TYPE_GO;  
        guiBoosterFlag = true;  
        guiAntPointTestOnlyFlag = true;
        PrintLog(1, "Product type = GO, set guiBoosterFlag=" + guiBoosterFlag + " set guiAntPointTestOnlyFlag=" + guiAntPointTestOnlyFlag);
    }
    else if( tempSku.search("Q34") == 4 )
    {
        tempProd = PRODUCT_TYPE_CABLE;    
    }
    else
    {
        tempProd = PRODUCT_TYPE_UNKNOWN;    
    }

    return( tempProd );
}  



// InitGetRegLockStatus...........................................................................................................
function InitGetRegLockStatus() 
{
    uRegLockStateCounter = 0; 
}

// GetRegLockStatus...........................................................................................................
// Call until function returns true which means that we have received Reg Lock status 
// and variable nxtyRxRegLockStatus has been updated.
function GetRegLockStatus() 
{
    if( uRegLockStateCounter == 0 )
    {
        if( SetUartToNu() == true )
        {
          uRegLockStateCounter  = 1;
        }
    }
    
    if( uRegLockStateCounter == 1 )
    {
        nxtyReadAddrRsp = 0;
        WriteAddrReq( NXTY_PCCTRL_CLOUD_INFO, CLOUD_INFO_REG_LOCK_BITS_CMD );
        uRegLockStateCounter  = 2;
    }
    else if( uRegLockStateCounter >= 2 )
    {                        
        if( bWriteAddrRsp )
        {
            if( (nxtyReadAddrRsp & CLOUD_INFO_CMD_RSP_BIT) != 0 )
            {
                // Got em...
                nxtyRxRegLockStatus  = nxtyReadAddrRsp & CLOUD_INFO_DATA_MASK;
                uRegLockStateCounter = 0;
                
                guiRegistrationLockBits = nxtyRxRegLockStatus;
           
                var rLock = (nxtyRxRegLockStatus & 0x08)?"Reg Desired":"";
                rLock    += (nxtyRxRegLockStatus & 0x04)?"/Reg Required":"";
                rLock    += (nxtyRxRegLockStatus & 0x02)?"/Reg Complete":"";
                rLock    += (nxtyRxRegLockStatus & 0x01)?"/Loc Lock":"";
                PrintLog(1,  "  RegLock=0x" + nxtyRxRegLockStatus.toString(16).toUpperCase() + " (" + rLock + ")");               
                
                SetUartLocal();            // If remote then cancel the UART redirect...if local then no problem...
                return( true );
            }
            else
            {
                // Read to get Reg Lock bits...
                ReadAddrReq( NXTY_PCCTRL_CLOUD_INFO );
            }
        }
        else
        {
            uRegLockStateCounter++;
            
            if( uRegLockStateCounter > 4 )
            {
                // Send the message again if we do not get a response...
                InitGetRegLockStatus();
            }
        }
    }                        
    
    
    return( false );
}  

// rtnHexAsciiOrZero...........................................................................................................
function rtnHexAsciiOrZero(inByte) 
{
    if( ((inByte >= 0x30) && (inByte <= 0x39)) ||       // 0 to 9
        ((inByte >= 0x41) && (inByte <= 0x46)) ||       // A to F
        ((inByte >= 0x61) && (inByte <= 0x66)) )        // a to f
    {
        return( inByte );
    }
        
    return( 0x30 ); // Return ASCII zero.
    
}





// LocationLockLoop .................................................................................................................
// Called periodically to send a request for RegSupportData...
function LocationLockLoop()
{
    
    // See if we are still in cell-search...
    if( (nxtyRegSupportData & REG_SUPPORT_DATA_TYPE_MASK) == REG_SUPPORT_DATA_TYPE_CELL_SEARCH )
    {
        // Cell-search is still in progress, request more data and come back...
        if( guiSoftwareStatus != SW_STATUS_UPDATE_IN_PROGRESS )
        {
            PrintLog(1, "LocationLockLoop() Cell search still in progress... Reg Support = 0x" + nxtyRegSupportData.toString(16) );
            RequestRegSupportData();
        }
        else
        {
            PrintLog(1, "LocationLockLoop() Wait for SW update to complete before checking on Cell Search progress..." );
        }
        setTimeout( LocationLockLoop, 30000 );
    }
    else
    {
    
    
        // No longer in cell search, see if the location lock bit is still set.
        // The reg lock bits are 0x4Rsp where R is the reg lock bits.
        nxtyRxRegLockStatus = (nxtyRegSupportData & 0x0F00) >> 8;
        
        PrintLog(1, "LocationLockLoop() Cell search complete... Evaluate RegLock bits = 0x" + nxtyRxRegLockStatus.toString(16) );
         
        EvalRegLockBits();
        
        // If registration is needed then explain to user...
        if( guiCurrentMode == PROG_MODE_REGISTRATION )
        {
            ShowAlertPopUpMsg( GetLangString('RegRequired'), GetLangString('PleaseRegisterProductToUse'));
        }
    }
}


// RequestRegSupportData .................................................................................................................
var RequestRegSupportDataTimer = null;
function RequestRegSupportData()
{
    if( RequestRegSupportDataTimer != null )
    {
        clearTimeout(RequestRegSupportDataTimer);
    }
    
    // If some message is pending then schedule a come back at an odd interval...
    if( isNxtyMsgPending() == true )
    {
        RequestRegSupportDataTimer = setTimeout( RequestRegSupportData, 121 );
    }
    else
    {
        GetRegSupportData();
        RequestRegSupportDataTimer = null;
    }
    
}


// EvalRegLockBits .................................................................................................................
//  0x00    No action           0x04    register        0x08    no action    
//  0x01    Call provider       0x05    register        0x09    register
//  0x02    not possible        0x06    no action       0x0A    no action
//  0x03    Call provider       0x07    register        0x0B    register
function EvalRegLockBits()
{
    
    if((nxtyRxRegLockStatus == 0x00) || (nxtyRxRegLockStatus == 0x01) || (nxtyRxRegLockStatus == 0x02) || (nxtyRxRegLockStatus == 0x03) || (nxtyRxRegLockStatus == 0x06) || (nxtyRxRegLockStatus == 0x0A))
    {
        if( (nxtyRxRegLockStatus == 0x01) || (nxtyRxRegLockStatus == 0x03) )     // State 2 (0x01) or state 4 (0x03):  Loc Lock bit set.
        {
            var eText;
            if( nxtyRxRegLockStatus == 0x01 )
            {
                eText = GetLangString("LocationLockMsg1");   // "Please call your service provider. (Reg State 2)";
            }
            else
            {
                eText = GetLangString("LocationLockMsg2");   // "Please call your service provider. (Reg State 4)";
            }
            ShowAlertPopUpMsg(GetLangString("LocationLockSet"),  eText);
            UpdateStatusLine( eText + "<br>Cnx: " + myModel + ":" + mySn );                             
        }

        // Jira WaveApp-55: Always send NEWSITE, even if not registering...
        SendCloudOperatorRegistrationInfo( true, "", "", "", "", "", "", "", "", "", "", "" );

        isRegistered = true;
        RequestModeChange(PROG_MODE_TECH);
    }
    else if((nxtyRxRegLockStatus == 0x04) || (nxtyRxRegLockStatus == 0x05) || (nxtyRxRegLockStatus == 0x07) || (nxtyRxRegLockStatus == 0x09) || (nxtyRxRegLockStatus == 0x0B))
    {
        isRegistered = false;
        
        // MAIN is only first pass through the MAIN loop when screen is showing Syncing.
        if( (guiCurrentMode == PROG_MODE_MAIN) || (guiCurrentMode == PROG_MODE_TECH)  )
        {
            bRegisterAsNew = true;
            RequestModeChange(PROG_MODE_REGISTRATION); //Loading registration screen without prompting to user
        }
        else
        {
            PrintLog(1, "Registration mode needed but not allowed since system is busy." );
            SendCloudOperatorRegistrationInfo( true, "", "", "", "", "", "", "", "", "", "", "" );  // Send a NEWSITE to support WaveApp-93.  Send edit later.
            ShowAlertPopUpMsg( GetLangString("RegRequired"), GetLangString("RegRestart") );
        }
    }
    else if(nxtyRxRegLockStatus == 0x08)
    {
        // Jira WaveApp-55: Always send NEWSITE, even if not registering...
        SendCloudOperatorRegistrationInfo( true, "", "", "", "", "", "", "", "", "", "", "" );
    
        isRegistered = false;
        RequestModeChange(PROG_MODE_TECH);
    }
      
    guiRegistrationFlag = isRegistered;
                                            
    
    // Look at the registered status to update the cloud.   Must wait until after the nxtyRxRegLockStatus check above
    // so the logic will update the isRegistered variable.
    if( isRegistered )
    {
        SendCloudTechData( "'TNM_Registered':" + 1 );
    }
    else
    {
        SendCloudTechData( "'TNM_Registered':" + 0 );
    }
}

// jLog10 .................................................................................................................
// Mobile browser does not support Math.log10()...
function jLog10(val) 
{
  return( Math.log(val) / Math.LN10 );
}


/*
jdo: used for GPS tracking while driving for GO
var bGpsOnMsg = false;

function geoTrack()
{ 
    navigator.geolocation.getCurrentPosition(geoSuccessTrack, geoErrorTrack, {timeout:9000});
}



function geoSuccessTrack(position) 
{
    SendCloudData( "'latTrack':" + position.coords.latitude + ", 'longTrack':" + position.coords.longitude );
    
    // If we have a success we do not want to throw up an error message later.
    bGpsOnMsg = true;  
}


function geoErrorTrack(error) 
{
    PrintLog(1, "geoErrorTrack(): GPS error on phone while tracking." );
    
    if( bGpsOnMsg == false )
    {
        bGpsOnMsg = true;
        
        ShowAlertPopUpMsg( GetLangString("LocationService"),  GetLangString("LocationServiceOff")  );
    }
}

*/
