//=================================================================================================
//
//  File: registration.js
//
//  Description:  This file contains the functions necessary for registering our product.
//
//=================================================================================================

var RegLoopIntervalHandle   = null;
var regSubState             = 0;
var u8rsp                   = null;


const REG_STATE_INIT                        = 1;
const REG_STATE_CHECK_CELL_SEARCH_COMPLETE  = 2;
const REG_STATE_CELL_INFO_REQ               = 3;
const REG_STATE_CELL_INFO_RSP               = 4;
const REG_STATE_OPER_REG_RSP                = 5;
const REG_STATE_REGISTRATION_RSP            = 6;
const REG_STATE_DONE                        = 7;
var    regState                = REG_STATE_DONE;


const regStateNames                 = ["N/A", "Init", "Cell Search Complete", "Cell Info Req", "Cell Info Rsp", "Oper Reg Rsp - Wait on Cloud", "Reg Rsp - Wait on Cel-Fi"];



const REG_NAK_COUNT_MAX             = 2;
const REG_LOOP_COUNT_MAX            = 60;


// Values for RegSupportData
const REG_SUPPORT_DATA_TYPE_MASK        = 0xF000;
const REG_SUPPORT_DATA_TYPE_CELL_SEARCH = 0x4000;

// Percentage per stage provided by JC.
const stagePercentArray = [0, 50/1800, 100/1800, 150/1800, 300/1800, 300/1800, 100/1800, 0, 800/1800];



// Reg data items shared with cloud..
var myPlmnid                    = "no plmind";
var myRegDataToOp               = "registration data to operator";
var myRegDataFromOp             = null;
var myRegOpForce                = null;

var regTimeoutCount             = 0;
var RegNakCount                 = 0;






// Geolocation Callbacks
// HandleConfirmLocation.......................................................................................
// process the confirmation dialog result
function HandleConfirmLocation(buttonIndex) 
{
    // buttonIndex = 0 if dialog dismissed, i.e. back button pressed (do nothing).
    // buttonIndex = 1 if 'Yes' to use location information.
    // buttonIndex = 2 if 'No'
    if( buttonIndex == 1 )
    {
        // Request location...
        ShowWaitPopUpMsg( GetLangString('PleaseWait'), GetLangString('AcquiringLocationInformation') );
        
//        var options = {maximumAge: 0, timeout: 10000, enableHighAccuracy:true};
//        var options = { timeout: 31000, enableHighAccuracy: true, maximumAge: 90000 };
//        navigator.geolocation.getCurrentPosition(geoSuccess, geoError, options);
        navigator.geolocation.getCurrentPosition(geoSuccess, geoError, {timeout:10000});

    }
    
    // No:  Do not use location information so return to main menu immediately...
    if( buttonIndex == 2 )
    {
        //reg.handleBackKey();
    	RequestModeChange(PROG_MODE_TECH);
    }        
}



// This method accepts a Position object, which contains the
// current GPS coordinates
//
function geoSuccess(position) 
{
    StopWaitPopUpMsg();
    var myLat  = "" + position.coords.latitude;
    var myLong = "" + position.coords.longitude;
    SendCloudOperatorRegistrationInfo( false, "", "", "", "", "", "", "", "", "", myLat, myLong );
    
    RequestModeChange(PROG_MODE_TECH);
    
/*    
    alert('Latitude: '          + position.coords.latitude          + '\n' +
          'Longitude: '         + position.coords.longitude         + '\n' +
          'Altitude: '          + position.coords.altitude          + '\n' +
          'Accuracy: '          + position.coords.accuracy          + '\n' +
          'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
          'Heading: '           + position.coords.heading           + '\n' +
          'Speed: '             + position.coords.speed             + '\n' +
          'Timestamp: '         + position.timestamp                + '\n');
*/          
}


// geoError Callback receives a PositionError object
//
function geoError(error) 
{
    StopWaitPopUpMsg();

    ShowConfirmPopUpMsg( "KEY_UNABLE_TO_ACQUIRE_GPS",   // title
        "No location information will be stored.",      // message
        HandleLocationBack,                             // callback to invoke with index of button pressed
        ['ok'] );                                       // buttonLabels
}


function HandleLocationBack(buttonIndex) 
{
    // Just go back...
    reg.handleBackKey();
}

function ProcessRegistration( firstName, lastName, addr1, addr2, city, state, zip, country, phone )
{
    if(bRegisterAsNew)
    {
        SendCloudOperatorRegistrationInfo( true, firstName, lastName, addr1, addr2, city, state, zip, country, phone, "", "" );
    }
    else
    {
        // WaveApp-93: Send an EDITSITE.
        SendCloudOperatorRegistrationInfo( false, firstName, lastName, addr1, addr2, city, state, zip, country, phone, "", "" );
    }
    
    // Start the registration...
    if( isRegistered == false )
    {
        if( regState == REG_STATE_DONE )
        {
            regState = REG_STATE_INIT;
            reg.RegLoop();
        }
    }
    else
    {
        ShowAlertPopUpMsg(GetLangString('AlreadyRegistered'), GetLangString('NoNeedToRegister'));
    }
}


var reg = {

    // Handle the Back key
    handleBackKey: function()
    {
        PrintLog(1, "");
        PrintLog(1, "Reg: Reg Mode Back key pressed--------------------------------------------------");
             
        if( isRegistered == false )
        {
            // Save any typed data in case user comes back...
            SaveRegFormData();
        }

        clearInterval(RegLoopIntervalHandle);
        regState = REG_STATE_DONE;      
        //app.renderHomeView();
        //util.closeApplication();
    },


    
    renderRegView: function() 
    {    
        PrintLog(1, "RenderRegView()...");
        guiRegistrationPercent = -1;
        guiCurrentMode         = PROG_MODE_REGISTRATION;
        regState               = REG_STATE_DONE;
        DisplayLoop();
    },


    RegLoop: function() 
    {
        var u8Buff  = new Uint8Array(20);
        
        regTimeoutCount += 1;
        
        // Always report this loop since so many substates with V2 protocol...
        PrintLog(1, "Reg: Reg loop... state = " + regStateNames[regState] + " substate=" + regSubState );
        
        switch( regState )
        {
            case REG_STATE_INIT:
            {
                UpdateStatusLine("Verifying System Information...");
                ShowWaitPopUpMsg(GetLangString('Validation'), GetLangString('VerifySysInfo'));
                regState              = REG_STATE_CHECK_CELL_SEARCH_COMPLETE;
                RegLoopIntervalHandle = setInterval(reg.RegLoop, 1000 );
                regTimeoutCount       = 0;
                RegNakCount           = 0;
                 
                // Get the Reg Data from the CU...
                GetRegSupportData();
                break; 
            }


            case REG_STATE_CHECK_CELL_SEARCH_COMPLETE:
            {
                // Wait in this state until the Cel-Fi unit is in PLACE state or greater, i.e. Cell Search Complete...
                if( bNxtySuperMsgRsp == true )
                {
                    if( (nxtyRegSupportData & REG_SUPPORT_DATA_TYPE_MASK) == REG_SUPPORT_DATA_TYPE_CELL_SEARCH )
                    {
                        PrintLog(1, "RegSupportData: 0x" + nxtyRegSupportData.toString(16) );
                                            
                        // Update the progress bar with the current status...
                        var i;
                        var currentStage    = ((nxtyRegSupportData & 0x00F0) >> 4);
                        const maxStage      = 8;
                        var percentComplete = 0;
                        
                        // Limit to the max number of stages to 8
                        if( currentStage > maxStage )
                        {
                            currentStage = maxStage;
                        }
                        
                        // Add the percent per stage up to the current stage.
                        for( i = 0; i <= maxStage; i++ )
                        {
                            if( i < currentStage )
                            {
                                percentComplete += stagePercentArray[i];
                            }
                        }

                        // Convert from decimal to percent...
                        percentComplete *= 100;
                        
                        
                        // Add the current stage percentage...
                        percentComplete += ((nxtyRegSupportData & 0x000F) * 10) * stagePercentArray[currentStage];
                        
                        // Round to the nearest integer...
                        percentComplete = Math.round(percentComplete);
                        
                        if( percentComplete > 100 )
                        {
                            percentComplete = 100;
                        }
                        
                        
                        // Update the progress bar...
                        guiRegistrationPercent = percentComplete;
                        
                        // Showing or updating cell search progress
                        if(cellSearchProgressFlag){
                        	util.updateCellSearchProgressBar(guiRegistrationPercent);
                        }else{
                        	cellSearchProgressFlag = true;
                        	util.showCellSearchProgressPopup();
                        }
                        
//                      document.getElementById('pbar_id').value = percentComplete;
//                      $('.progress-value').html(percentComplete + '%');
                        
                        
                        // Request updated status from CU...
                        GetRegSupportData();
                        
                        // Do not time out of this state as Cell Search can take up to 1 hour...
                        regTimeoutCount = 0;
                    }
                    else
                    {
                        // Unit is no longer in Cell Search so remove progress bar and go to the next step.
//                        document.getElementById("p_id").innerHTML = ""; 
                        guiRegistrationPercent = -1;
                        regState               = REG_STATE_CELL_INFO_REQ;
                        regTimeoutCount        = 0;
                        
                        // Hiding cell search progress bar
                        util.removeCellSearchProgressPopup();
                    }
                

                }
                else if( msgRxLastCmd == NXTY_NAK_RSP )
                {   
                    // Try again if CRC NAK...
                    if( (nxtyLastNakType == NXTY_NAK_TYPE_CRC) || (nxtyLastNakType == NXTY_NAK_TYPE_TIMEOUT) )
                    {
                        if( RegNakCount++ >= REG_NAK_COUNT_MAX )
                        {
                            clearInterval(RegLoopIntervalHandle);
                            regState = REG_STATE_DONE;
                            StopWaitPopUpMsg();
                            UpdateStatusLine("Failed to receive response from Cel-Fi device.");
                            ShowAlertPopUpMsg((nxtyLastNakType == NXTY_NAK_TYPE_CRC)?GetLangString("RegCrcMax"):GetLangString("Timeout"), GetLangString("RegResponseFail") );
                        }
                        else
                        {
                            // Try again...
                            GetRegSupportData();
                        }
                    }
                }


                // Safety to keep sending if BT issue...
                if( regTimeoutCount >= 2 )
                {
                    // Request updated status from CU...
                    GetRegSupportData();
                    RegNakCount = 0;    // Do not CRC out...   
                }
                
                // Safety exit...
                if( regTimeoutCount >= REG_LOOP_COUNT_MAX )
                {
                    // after so many times exit stage left...
                    clearInterval(RegLoopIntervalHandle);
                    regState = REG_STATE_DONE;
                        
                    StopWaitPopUpMsg();
                    UpdateStatusLine("Timeout: Failed to receive response from Cel-Fi device.");
                    ShowAlertPopUpMsg(GetLangString('Timeout'), GetLangString('NoResponseFromCelFiDevice'));
                }

                regSubState = 0;
                break;
            }



            // Request the CELL information from the Cel-Fi unit.
            case REG_STATE_CELL_INFO_REQ:
            {
                // 4/18/16:  With Azure, no longer request cell info directly but allow
                // tech mode to run and indirectly send cell info to the cloud. 
                if( regSubState == 0 )                   
                {
                    // Start tech mode...
                    PrintLog(1, "Reg: Request cell info by starting tech mode and allowing to run for a few seconds." ); 
                    sendTechToCloudPeriodSec   = 2;      // 2 second update
                    StartGatheringTechData();
                }
                
                regSubState++;
                
                if( regSubState > 10 )                   
                {
                    // After so many seconds, kill tech mode and move on...
                    StopGatheringTechData();
                    sendTechToCloudPeriodSec   = 60;      // back to 1 minute
                    regSubState = 0;
                    regState    = REG_STATE_CELL_INFO_RSP;
                }                
            
            
            
                break;
            }
            
            
            
            // Use this state to send the Reg request to the cloud.
            case REG_STATE_CELL_INFO_RSP:
            {
                UpdateStatusLine("Waiting for Operator response ... ");
                ShowWaitPopUpMsg(GetLangString('Registering'), GetLangString('RequestingOperatorInfo'));
                regState        = REG_STATE_OPER_REG_RSP;
                regTimeoutCount = 0;
                RegNakCount     = 0;
                myRegOpForce    = null;                    
                myRegDataFromOp = null;
                regSubState     = 0;
                SendCloudOperatorRegistration();
            
                break;
            }
            
            
            // Wait on response from the cloud, i.e. Egress response...
            case REG_STATE_OPER_REG_RSP:     
            {
                if( nxtyRxStatusIcd <= V1_ICD )
                {
                    // Poll the cloud...
//                    SendCloudPoll();
                    
                
                    if( (myRegOpForce != null)  && (regTimeoutCount > 6) )      // Wait at least 5 seconds for UART redirect to time out )
                    {
                        // Grab the data from the cloud, i.e. operator...
                        PrintLog(1, "Egress: regOpForce = " + myRegOpForce );

                        if( myRegOpForce == 'true' )
                        {   
                            var temp  = "regOpForce:true";
                            u8rsp = stringToBytes(temp);
                        }
                        else
                        {
                            u8rsp = stringToBytes(myRegDataFromOp);
                        } 
                        
    
                        
                        // Send a registration request to the Cel-Fi... 
                        nxty.SendNxtyMsg(NXTY_REGISTRATION_REQ, u8rsp, u8rsp.length);
                        
    
                        UpdateStatusLine(GetLangString('Authenticating'));
                        ShowWaitPopUpMsg((GetLangString('Registering')), GetLangString('Authenticating'));                        
                        regState        = REG_STATE_REGISTRATION_RSP;
                        regTimeoutCount = 0;
                    }
                    else
                    {
    
                        UpdateStatusLine("Waiting for Operator response ... " + regTimeoutCount );
    
                        // Safety exit...
                        if( regTimeoutCount >= REG_LOOP_COUNT_MAX )
                        {
                            // after so many times exit stage left...
                            clearInterval(RegLoopIntervalHandle);
                            regState = REG_STATE_DONE;
                            
                            UpdateStatusLine("Failed to receive response from Operator.");
                            ShowAlertPopUpMsg(GetLangString('Timeout'), GetLangString('NoResponseFromOperator') );
                            
                        }
                    }
                
                
                }
                else
                {            
                    // Poll the cloud...
                    if( myRegOpForce == null )
                    {
//                        SendCloudPoll();
                        UpdateStatusLine("Waiting for Operator response ... " + regTimeoutCount );
    
                        // Talk to the NU while waiting here to keep the UART redirect from timing out...
                        GetNxtySuperMsgLinkStatus();
                    }
                    else
                    {
                        if( regSubState == 0 )                   // Redirect UART to Remote unit, should already be redirected.
                        {
                            if( (IsUartRemote() == false) && (bCnxToOneBoxNu == false) )     
                            {
                                SetUartRemote();
                            }
                            else
                            {
                                regSubState = 1;
                            }
                        }
                        else if( regSubState == 1 )              // Start the download to the NU
                        {
                            // Grab the data from the cloud, i.e. operator...
                            PrintLog(1, "Egress: regOpForce = " + myRegOpForce );
                            
                            
                            if( myRegOpForce == 'true' )
                            {   
                                var temp  = "regOpForce:true";
                                u8rsp = stringToBytes(temp);
                            }
                            else
                            {
                                u8rsp = stringToBytes(myRegDataFromOp);
                            } 
        
                            
                            // Send a message to the Cel-Fi unit to start downloading...
                            var u8TempBuff  = new Uint8Array(20);
                            var u8Len       = u8rsp.length;
                            u8TempBuff[0]   = NXTY_SW_NONE_TYPE;   
                            u8TempBuff[1]   = (nxtyNuCloudBuffAddr >> 24);    // Note that javascript converts var to INT32 for shift operations.
                            u8TempBuff[2]   = (nxtyNuCloudBuffAddr >> 16);
                            u8TempBuff[3]   = (nxtyNuCloudBuffAddr >> 8);
                            u8TempBuff[4]   = nxtyNuCloudBuffAddr;
                            u8TempBuff[5]   = (u8Len >> 24);                  // Note that javascript converts var to INT32 for shift operations.
                            u8TempBuff[6]   = (u8Len >> 16);
                            u8TempBuff[7]   = (u8Len >> 8);
                            u8TempBuff[8]   = (u8Len >> 0);
                            
                            nxty.SendNxtyMsg(NXTY_DOWNLOAD_START_REQ, u8TempBuff, 9);
                            
                            regSubState     = 2;
                        }
                        else if( regSubState == 2 )              // Wait for Start Download Response
                        {
                            // Wait in this state until the Cel-Fi unit responds...
                            if( window.msgRxLastCmd == NXTY_DOWNLOAD_START_RSP )
                            {
                                // Move on to next state...
                                regSubState     = 3;
                                regTimeoutCount = 0;
                            }
                            else if( window.msgRxLastCmd == NXTY_NAK_RSP )
                            {
                                // Try again...do not clear regSubState to allow NAKs to time out if multiple.   
                                regSubState  = 1;
                            }
    
                        }
                        else if( regSubState == 3 )              // Send Download data
                        {
                            var u8TempBuff  = new Uint8Array(NXTY_MED_MSG_SIZE);
        
                            u8TempBuff[0]   = NXTY_DOWNLOAD_MAX_SIZE;       // Chunksize: Indicate 128 bytes of data, mostly 0's
                        
                            // Start with 1 to account for u8TempBuff[0] set to chunksize
                            for( i = 0; i < u8rsp.length; i++ )
                            {
                                u8TempBuff[i+1] = u8rsp[i];
                            }
        
        
                            // Send a message to the Cel-Fi unit with data...
                            nxty.SendNxtyMsg(NXTY_DOWNLOAD_TRANSFER_REQ, u8TempBuff, (u8rsp.length + 1));
    
                            UpdateStatusLine("Authenticating ... ");
                            ShowWaitPopUpMsg(GetLangString('Registering'), GetLangString('Authenticating'));
                            
                            // Move on to next state...
                            regSubState     = 4;
                            regTimeoutCount = 0;                        
                        }
                        else if( regSubState == 4 )              // Wait for Download Xfer Response
                        {
                            // Wait in this state until the Cel-Fi unit responds...
                            if( window.msgRxLastCmd == NXTY_DOWNLOAD_TRANSFER_RSP )
                            {
                            
                                // Send a Download End...
                                var u8TempBuff  = new Uint8Array(2);
                                u8TempBuff[0] = 0;                      // No reset
                                nxty.SendNxtyMsg(NXTY_DOWNLOAD_END_REQ, u8TempBuff, 1);
                            
                                // Move on to next state...
                                regSubState     = 5;
                                regTimeoutCount = 0;
                            }
                            else if( window.msgRxLastCmd == NXTY_NAK_RSP )
                            {
                                // Try again...do not clear regSubState to allow NAKs to time out if multiple.   
                                regSubState  = 3;
                            }
    
                        }
                        else if( regSubState == 5 )              // Set Reg Req bit so NU will read buffer and process
                        {
                            // Wait in this state until the Cel-Fi unit responds...
                            if( window.msgRxLastCmd != NXTY_WAITING_FOR_RSP )
                            {
                                // Send to Ares...
                                nxtyReadAddrRsp = CLOUD_INFO_REG_REQ_CMD;                  // Prime the read response
                                WriteAddrReq( NXTY_PCCTRL_CLOUD_INFO, CLOUD_INFO_REG_REQ_CMD );
                                
                                // Move on to next state...
                                regSubState     = 6;
                            }                        
                        }
                        else if( regSubState == 6 )              // Wait until reg req has been processed...
                        {
                            if( bWriteAddrRsp )
                            {
                                // Move on to next state...
                                InitGetRegLockStatus();
                                regSubState     = 7;
                            }
                        }
                        else if( regSubState == 7 )              // Get updated RegLock bits...
                        {
                            if( GetRegLockStatus() == true )
                            {
                                if( nxtyRxRegLockStatus & 0x02 )
                                {
                                   // Registered...
                                   UpdateRegIcon(1);
                                }
                                else
                                {
                                   // Not registered...
                                   UpdateRegIcon(0);
                                }
                                
                                // move on
                                regState        = REG_STATE_REGISTRATION_RSP;
                                regTimeoutCount = 0;
                                regSubState     = 0;
                            }
                                
                        }
                        
    
                    }
    
                    // Safety exit...
                    if( regTimeoutCount >= REG_LOOP_COUNT_MAX )
                    {
                        // after so many times exit stage left...
                        clearInterval(RegLoopIntervalHandle);
                        regState = REG_STATE_DONE;
                        
                        StopWaitPopUpMsg();
                        
                        if( myRegOpForce == null )
                        {
                            UpdateStatusLine("Failed to receive response from Operator.");
                            ShowAlertPopUpMsg(GetLangString('Timeout'), GetLangString('NoResponseFromOperator') );
                        }
                        else
                        {
                            UpdateStatusLine("Failed to receive response from Cel-Fi Unit.");
                            ShowAlertPopUpMsg(GetLangString('Timeout'), GetLangString('Timeout'));
                        }
                        
                    }
                }

                break;
            }

            
            case REG_STATE_REGISTRATION_RSP:
            {
                if( nxtyRxStatusIcd <= V1_ICD )
                {
                    // Wait on response from Cel-Fi.
                    if( msgRxLastCmd == NXTY_REGISTRATION_RSP )
                    {
                        // We have received the response from the Cel-Fi unit..
                        
                        // Stop the rotating wheel...
                        StopWaitPopUpMsg();
                        
                        if( isRegistered )
                        {
                            UpdateStatusLine("Registration successful...");
                            var d = new Date();
//                            SendCloudData( "'RegDate':'" + d.toLocaleDateString() + "'" );
                            SendCloudTechData( "'TNM_Registered':" + 1 );

                            if(window.device.platform != pcBrowserPlatform)
                            {
                                ShowConfirmPopUpMsg( "KEY_LOCATION",                        // title
                                    GetLangString('RegistrationSuccessfulProvideInfo'),     // message
                                    HandleConfirmLocation,                                  // callback to invoke with index of button pressed
                                    ['Yes', 'No'] );                                        // buttonLabels
                            }
                            else
                            {
                                HandleConfirmLocation(2);
                            }
                            
                            
                        }
                        else
                        {
                            UpdateStatusLine("Registration not successful...");
                            SendCloudTechData( "'TNM_Registered':" + 0 );
                            
                        }
                        clearInterval(RegLoopIntervalHandle);
                        regState = REG_STATE_DONE;
                        
                    }
                    else if( msgRxLastCmd == NXTY_NAK_RSP )
                    {   
                        // Try again if CRC NAK...
//                        if( nxtyLastNakType == NXTY_NAK_TYPE_CRC )
                        {
                            regState = REG_STATE_OPER_REG_RSP;
                            
                            if( RegNakCount++ >= REG_NAK_COUNT_MAX )
                            {
                                clearInterval(RegLoopIntervalHandle);
                                regState = REG_STATE_DONE;
                                
                                StopWaitPopUpMsg();                                
                                UpdateStatusLine("Failed to receive Authentication response from Cel-Fi device due to CRC error.");
                                ShowAlertPopUpMsg(GetLangString("RegCrcMax"), GetLangString("RegAuthFail") );
                            }
                        }
                    }
                    else
                    {
                        UpdateStatusLine("Authenticating ... " + regTimeoutCount);
                    }
                    
                               
                    // Safety exit...
                    if( regTimeoutCount >= REG_LOOP_COUNT_MAX )
                    {
                        // after so many times exit stage left...
                        clearInterval(RegLoopIntervalHandle);
                        regState = REG_STATE_DONE;
                        
                        StopWaitPopUpMsg();
                        UpdateStatusLine("Failed to receive Authentication response from Cel-Fi device.");
                        ShowAlertPopUpMsg(GetLangString('Timeout'), GetLangString('RegAuthFail') );
                    }
                
                }
                else    // V2 PIC
                {            
            
                    // Stop the rotating wheel...
                    StopWaitPopUpMsg();
                    
                    // Make sure that we are back local...
                    SetUartLocal();
                    
                    
                    if( isRegistered )
                    {
                        UpdateStatusLine("Registration successful...");
                        var d = new Date();
//                        SendCloudData( "'RegDate':'" + d.toLocaleDateString() + "'" );
                        SendCloudTechData( "'TNM_Registered':" + 1 );
                        
                        if(window.device.platform != pcBrowserPlatform)
                        {
                        ShowConfirmPopUpMsg( "KEY_LOCATION",                        // title
                            GetLangString('RegistrationSuccessfulProvideInfo'),     // message
                            HandleConfirmLocation,                                  // callback to invoke with index of button pressed
                            ['Yes', 'No'] );                                        // buttonLabels
                        }
                        else
                        {
                            HandleConfirmLocation(2);
                        }
                    }
                    else
                    {
                        UpdateStatusLine("Registration not successful...");
                        SendCloudTechData( "'TNM_Registered':" + 0 );
                        
                    }
                    clearInterval(RegLoopIntervalHandle);
                    regState = REG_STATE_DONE;
                }
                    
                break;
            }
            
            
            
            case REG_STATE_DONE:
            default:
            {
//                  clearInterval(RegLoopIntervalHandle);
                break;
            }
        }
        
        

        
    },
};






    
