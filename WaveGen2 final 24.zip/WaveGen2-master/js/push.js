//=================================================================================================
//
//  File: push.js
//
//  Description:  Support file which contains all functionality to "push" alerts to the phone.
//
//=================================================================================================

// Global file variables.......................................................
//var pushNotification;       

// Local file variables........................................................



// Global System calls ..........................................................................................



//This is a start for the new phonegap-plugin-push which is supposed to replace the com.phonegap.plugins.pushplugin plugin but has a different API.
var pushAndroid;       
var pushIos;

// Android..........................................................................................................
// InitGcmPush......................................................................................................
//
//   Initializes the Android Google Cloud Messaging (GCM) service.
// 
//  Input: device id
//
//  Outputs: none
//
function InitGcmPush() 
{
    PrintLog(1, "Push: Init Android Push()" );
    
    pushAndroid = PushNotification.init({
        android: {
            senderID: "1061836550351"
        }
    });
    
    
    pushAndroid.on('registration', function(data) {
        PrintLog(1, "Push: Android registration = " + JSON.stringify(data) );
        SendCloudAssociatePush( "GCM", data.registrationId );  
    });

    pushAndroid.on('notification', function(data) {
        PrintLog(1, "Push: Android notification = " + JSON.stringify(data) );
        ShowAlertPopUpMsg( GetLangString("PushAlert"), GetLangString("NewSwAvailable") );       // data.message must be "New Cel-Fi Software Available"
        // data.message,
        // data.title,
        // data.count,
        // data.sound,
        // data.image,
        // data.additionalData
    });
    
    pushAndroid.on('error', function(e) {
        PrintLog(99, "Push Android GCM: error = " + e.message );
    });
       
} 

    







// IOS..............................................................................................................
// InitIosPush......................................................................................................
//
//   Initializes the Apple IOS service.
// 
//
//  Outputs: none
//
function InitIosPush() 
{
    PrintLog(1, "Push:  InitIosPush()" );
    
    pushIos = PushNotification.init({
        ios: {
            alert: "true",
            badge: "true",
            sound: "true"
        }
    });   
    
    
    pushIos.on('registration', function(data) {
        PrintLog(1, "Push: IOS registration = " + JSON.stringify(data) );
        SendCloudAssociatePush( "APN", data.registrationId );  
    });
    
    pushIos.on('notification', function(data) {
        PrintLog(1, "Push: IOS notification = " + JSON.stringify(data) );
        ShowAlertPopUpMsg( GetLangString("PushAlert"), GetLangString("NewSwAvailable") );       // data.message must be "New Cel-Fi Software Available"
        
        if( data.count )
        {
            pushNotification.setApplicationIconBadgeNumber(function() {
                PrintLog(1, "Push: IOS success Badge callback!" );    
            }, function() {
                PrintLog(1, "Push: IOS error Badge callback!" );    
            }, data.count );
        }
        
        // data.message,
        // data.title,
        // data.count,
        // data.sound,
        // data.image,
        // data.additionalData
    });
    
    pushIos.on('error', function(e) {
        PrintLog(99, "Push IOS: error = " + e.message );
    });

    
     
} 







