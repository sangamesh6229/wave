//=================================================================================================
//
//  File: pcApp_cloud.js
//
//  Description:  This file contains the actual Northbound network calls to the cloud.
//
//=================================================================================================

var isNetworkConnected = null;
var networkErrorCount  = 0;

var QtNbManager        = null; // Qt object that will do the work


// SendNorthBoundData............................................................................................
function SendNorthBoundData( nType, nUrl, nContentType, nData, nRespFormat, nHeader, successCb, errorCb )
{
    // Verify that we have network connectivity....
    isNetworkConnected = NorthBoundConnectionActive();
    //PrintLog(1, "**SNBD type=" + nType);
    //PrintLog(1, "**SNBD url=" + nUrl);
    //PrintLog(1, "**SNBD hdr=" + JSON.stringify(nHeader));
    //PrintLog(1, "**SNBD dta=" + String(u8Data)); String(u8AzureTxBuff.subarray(0,i)));??

    if( isNetworkConnected )
    {
        if( nHeader.length == 0 )
        {
            // Send data to the cloud using a jQuery ajax call...        
            $.ajax({
                type       : nType,
                url        : nUrl,
                contentType: nContentType,
                data       : nData,
                crossDomain: true,                  // Needed to set to true to talk to Nextivity server.
                dataType   : nRespFormat,           // Response format
                success    : successCb,             // Success callback
                error      : errorCb,               // Error callback
                timeout    : 10000                  // sets timeout to 10 seconds
            });
        }
        else
        {
            // Send data to the cloud using a jQuery ajax call with headers...        
            $.ajax({
                type       : nType,
                url        : nUrl,
                contentType: nContentType,
                data       : nData,
                crossDomain: true,                  // Needed to set to true to talk to Nextivity server.
                dataType   : nRespFormat,           // Response format
                headers    : nHeader,
                success    : successCb,             // Success callback
                error      : errorCb,               // Error callback
                timeout    : 10000                  // sets timeout to 10 seconds
            });
        }
    }
    else
    {
        PrintLog( 99, "SendNorthBoundData: No network connection (WiFi or Cell)." );
    }
}

// SendNorthBoundDataBinary............................................................................................
function SendNorthBoundDataBinary( nType, nUrl, nContentType, u8Data, nLen, nRespFormat, nHeader, successCb, errorCb )
{
    // Verify that we have network connectivity....
    isNetworkConnected = NorthBoundConnectionActive();
    //PrintLog(1, "**SNBDb type=" + nType);
    //PrintLog(1, "**SNBDb url=" + nUrl);
    //PrintLog(1, "**SNBDb hdr=" + JSON.stringify(nHeader));
    //PrintLog(1, "**SNBDb dta=" + String(u8Data)); String(u8AzureTxBuff.subarray(0,i)));??

    if( isNetworkConnected )
    {
        // Create an array of the exact size to send...
        var u8Send = new Uint8Array(nLen);
        for( var j = 0; j < u8Send.length; j++ )
        {
            u8Send[j] = u8Data[j];
        }
    
  
        // Send data to the cloud using a jQuery ajax call with headers...        
        $.ajax({
            type       : nType,
            url        : nUrl,
            contentType: nContentType,
            data       : u8Send,
            crossDomain: true,                  // Needed to set to true to talk to Nextivity server.
            dataType   : nRespFormat,           // Response format
            processData: false,                 // Set to false so that binary data can be sent.
            headers    : nHeader,
            success    : successCb,             // Success callback
            error      : errorCb,               // Error callback
            timeout    : 10000                  // sets timeout to 10 seconds
        });
    }
    else
    {
        PrintLog( 99, "SendNorthBoundDataBinary: No network connection (WiFi or Cell)." );
    }
}


// NorthBoundConnectionActive............................................................................................
function NorthBoundConnectionActive()
{
    if( navigator.connection.ManualCheckInternetUp() == false )
    {
        if( (guiPopupDisplayed == false) && (networkErrorCount > 10) )
        {
            var eText = "Unable to connect to cloud, no WiFi or Cell available.";
            ShowConfirmPopUpMsg( "KEY_NO_WIFI_OR_CELL", // title
                eText,                                  // message filled in by handler
                HandleCloudRetry,                       // callback to invoke with index of button pressed
                ['Retry'] );                            // buttonLabels                                     
        }
        else if( guiPopupDisplayed == true )
        {
            networkErrorCount = 0;
        }
        else
        {        
            networkErrorCount++;
        }
        
        return( false );
    }
    else
    {
        networkErrorCount = 0;
        return( true );
    }
}

// FileTransferDownload..............................................................................................
//
//  Downloads a file from server.
// 
//  Input: fromUrl:  URL to download from including file name.
//         toUrl:    URL to download to including file name.
//
//  Outputs: none
//
//
function FileTransferDownload( fromUrl, toUrl )
{

    PrintLog(1, "FileTransferDownload: from: " + fromUrl + "  to: " + toUrl );

    // Perform a file transfer from the platform to the destination directory...        
    g_fileTransferSuccess   = null;
    
    if(QtNbManager != null)
    {
        QtNbManager.doDownload(fromUrl, toUrl);
    }
}

// Download from Cloud File transfer callback..................................................................
function FileTransferDownloadResponse(nPassFail, sFileName)
{
    PrintLog(10, "FileTransferDownloadResponse with " + nPassFail + " for " + sFileName);
    if(nPassFail == 0)
    {
        PrintLog(1, "Download from cloud successfully complete: " + sFileName);
        g_fileTransferSuccess = true;
    }
    else
    {
        PrintLog(99, "Download from cloud failed: " + sFileName + " Error code: " + nPassFail);
        g_fileTransferSuccess = false;
    }
    return 0;
}

// -------------------------------------------------------------------------------------------------------------
function FileTransferSaveBlobToFile(sFileName, uData)
{
    PrintLog(1, "FileTransferSaveBlobToFile=" + sFileName);
    if(QtNbManager != null)
    {
        QtNbManager.saveBytesToFile(sFileName, uData.length, uData);
    }
}


/*
SendCloudTechData:
PrintLog(1, "**SNBDtech type=POST");
PrintLog(1, "**SNBDtech url=" + myDataUrl);
PrintLog(1, "**SNBDtech hdr=" + JSON.stringify(myHeader));
PrintLog(1, "**SNBDtech dta=" + String(Array.apply([], u8AzureTxBuff.subarray(0,i)).join(",")));

SendCloudPoll:
PrintLog(1, "hfbAZURE:allHeaders=" + xhttp.getAllResponseHeaders() );

SendCloudTechPeriodDebug:
PrintLog(1, "**SNBDtechdbg type=POST");
PrintLog(1, "**SNBDtechdbg url=" + myDataUrl);
PrintLog(1, "**SNBDtechdbg hdr=" + JSON.stringify(myHeader));
PrintLog(1, "**SNBDtechdbg dta=" + String(Array.apply([], u8AzureTxBuff.subarray(0,i)).join(",")));

*/