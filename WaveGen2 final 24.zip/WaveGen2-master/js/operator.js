//=================================================================================================
//
//  File: operator.js
//
//  Description:  Contains functions to change operators on the Cel-Fi
//
//=================================================================================================

var szOperatorSkus               = null;            // Filled in by Cloud, OPERATORLIST, and looks like "590NP34NOCA2RGCA1B11RE,590NP34NOCA2WMCA1B11RA,590NP34NOCA2VMCA1B11RA"
var szOperatorCodeNames          = null;            // Filled in by call to Nextivity server and looks like: "A1AT:A1 Telecom Austria AG,AEBR:Accenture Brazil,ALSA:Aljawal STC Saudi Arabia,ATUS:AT&T"
var newOperatorSku               = null;
var bGetNewOperatorList          = false;           // Get a new list one time if we can't find something...

// GenerateOperatorList...........................................................................................................
// Called when both of the following have been filled in and builds a list in guiOperatorList[] and sets guiOperatorFlag to true. 
// Isolate the operator codes for each of the SKUs, bytes 12 to 15, and then find the name for that operator in the szOperatorCodeNames array.  
//    - szOperatorSkus         Filled in by Cloud, getOperatorInfoAction, and looks like "590NP34NOCA2RGCA1B11RE,590NP34NOCA2WMCA1B11RA,590NP34NOCA2VMCA1B11RA"
//    - szOperatorCodeNames    Filled in by call to Nextivity server and looks like: "A1AT:A1 Telecom Austria AG,AEBR:Accenture Brazil,ALSA:Aljawal STC Saudi Arabia,ATUS:AT&T"
//    - guiOperatorFlag        Flag:  true:  display operator selection 
//    - guiOperatorList        An array of operators to select.
function GenerateOperatorList() 
{
    var i;
    var j;
    
    PrintLog(1, "GenerateOperatorList(): szOperatorSkus=" + szOperatorSkus );
    
    if( (szOperatorSkus != null) && (szOperatorCodeNames != null) )
    {
        var tempSkuList = szOperatorSkus.split(",");            // Build an array of 590 values
        var tempOpList  = szOperatorCodeNames.split(",");       // Build an array of CODE:NAME pairs. 

        for( i = 0; i < tempSkuList.length; i++ )
        {
            var tempOpCode = tempSkuList[i].substring(12,16);
//            PrintLog(1,"SKU[" + i + "]=" + tempSkuList[i] + " Opcode=" + tempOpCode );
            
            for( j = 0; j < tempOpList.length; j++ )
            {
                if( tempOpList[j].search(tempOpCode) != -1 )
                {
                    // Get the name  CODE:NAME
                    guiOperatorList[i] = tempOpList[j].substring( tempOpList[j].search(":") + 1 ); 
                    guiOperatorFlag    = true;
                    break;
                }
            }
            
            if( j == tempOpList.length )
            {
                // Did not find a match for tempOpCode
                PrintLog(99, "No match found for " + tempOpCode );
                guiOperatorList[i] = tempOpCode + " No match found.";
                
                if( bGetNewOperatorList == false )
                {
                    // Try again...
                    PrintLog(1, "Get a new list from Nextivity server and try again in two seconds, one time only..." );
                    bGetNewOperatorList = true;
                    SendCloudParamGet(WAVE2_PARAMTYPE_OPERATORLISTALL, "", "", "");
                    
                    setTimeout(GenerateOperatorList, 2000);
                    return;
                }
            }
            
        } 
    }
    
    PrintLog(1, "  guiOperatorList=" + JSON.stringify(guiOperatorList)  );
}


// SetNewOperatorSku...........................................................................................................
// Called when user selects the name of the new operator. 
// The argument passed to this function is the index of the guiOperatorList[] which matches the list of 590s
// in the szOperatorSkus string.
//
//      
//      guiOperatorList[0] = "Rogers Canada" <-->    tempSkuList[0] = "590NP34NOCA2RGCA1B11RE"
//            etc...
function SetNewOperatorSku(opIndex) 
{
    var tempSkuList = szOperatorSkus.split(",");            // Regenerate an array of SKU (590) values
    newOperatorSku  = tempSkuList[opIndex];
    
    PrintLog(1, "SetNewOperatorSku(" + opIndex + ") ==> New Operator SKU=" + newOperatorSku );

    // Send new operator, i.e. new SKU.   
    // Cloud should use manufacturing SKU unless this SKU has been filled in.
    SendCloudParamSet(WAVE2_PARAMTYPE_SKU, newOperatorSku, "", "", "");                

    // Go to the download page and download all files...
    guiSoftwareStatus = SW_STATUS_UNKNOWN;
    RequestModeChange(PROG_MODE_DOWNLOAD_AUTO);
    
    // Clear local storage so the new operator code and text will be stored...
    window.localStorage.removeItem(nxtyCuUniqueId + "guiOperatorCode");
    window.localStorage.removeItem(nxtyCuUniqueId + "guiOperator");                        

    // Set the new SKU....
    ProcessSku(newOperatorSku.substring(0,20));
    
    // Store the SKU on the phone if new sku format, i.e. 20 bytes...
    if( mySku.length == 20 )
    {
        PrintLog( 1, "  Store SKU on phone to get later..." );
        window.localStorage.setItem(nxtyCuUniqueId, newOperatorSku);
    }

}


        
