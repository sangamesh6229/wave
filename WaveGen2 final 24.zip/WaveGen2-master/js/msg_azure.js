//=================================================================================================
//
//  File: msg_azure.js
//
//  Description:  This file is used to format communications with the Azure cloud.
//                Normal communications is via the Azure URL using binary data.
//
//=================================================================================================


//var platformName            = "NextivityIoTHubQA.azure-devices.net";
//var blobPlatformName        = "https://nextivitystorageqa.blob.core.windows.net";
//var sasHubKey               = "sJBd8gHBNQUcrCKqfbnAdW8wfGQNwcSbITesLa/9J3A=";       // Specific key for NextivityIoTHubQA.azure-devices.net 
var platformName            = null;
var blobPlatformName        = null;
var sasHubKey               = null;       // Specific key for NextivityIoTHubQA.azure-devices.net 
var regIotFlag              = null;       // "R" or "U" from Web socket server.
var secretKey               = "RLEjkjMYHoscIBCXavAyvK6371cesbCrImX4K2MRM9Q=";

var sandboxName             = "NextivityIoTHubDev.azure-devices.net";
var sandboxSasHubKey        = "Xh86c4aekfwLnqXQUz6VaFn/Q4jFQo/roGhuGbjfiJA=";       // Specific key for NextivityIoTHubDev.azure-devices.net 
var sasDevKey               = "";                                                   // Use RetrieveCloudDeviceKey() to return key
var sasDevKeyName           = "";
var sasHubKeyName           = "registryRead"; // "iothubowner";
var sasDevToken             = "";                                                   // Generated hourly by GenerateSasDevTokenHourly();
var platformVer             = "2016-02-03";
const CFG_RUN_ON_SANDBOX    = false;                                                 // true to run on Azure sandbox.  false to run on Azure production platform.


var azureDeviceId           = "";
var iMsgId                  = 0;
var pollAzureIntervalHandle = null; 
var szCloudRegStatus        = "";
var bFlushC2d               = true;

// Azure IOT Hub message data...
var u8AzureTxBuff = new Uint8Array(4096);
var u8NuUniqueId  = new Uint8Array(8);
var u8CuUniqueId  = new Uint8Array(8);

const   WAVE2_INTF_VER_1_0                      = 0x10;
const   APP_INTERFACE_VER                       = WAVE2_INTF_VER_1_0;



const   D2CMSG_TECHDATA                         = 1;
const     BOOSTERSETTINGS_AUTO                  = 1;
const     BOOSTERSETTINGS_3G                    = 2;
const     BOOSTERSETTINGS_LTE                   = 3;
const     BOOSTERSETTINGS_BANDA                 = 4;
const     BOOSTERSETTINGS_BANDB                 = 5;
const     BOOSTERSETTINGS_BANDC                 = 6;
const   D2CMSG_REGISTER_NEWSITE                 = 10;
const   D2CMSG_REGISTER_ASSOC_SYSTEM            = 11;
const   D2CMSG_REGISTER_DISASSOC_SYSTEM         = 12;
const   D2CMSG_REGISTER_ASSOC_BOARD             = 13;
const   D2CMSG_REGISTER_DISASSOC_BOARD          = 14;
const   D2CMSG_REGISTER_OPERATOR                = 15;
const   D2CMSG_REGISTER_ASSOC_NOTIFICATION      = 16;
const   D2CMSG_REGISTER_EDITSITE                = 17;
const   D2CMSG_PARAM_GET                        = 20;
const   D2CMSG_PARAM_SET                        = 21;
const    WAVE2_PARAMTYPE_FIRSTNAME              = 1;
const    WAVE2_PARAMTYPE_OPERATORLIST           = 2;
const    WAVE2_PARAMTYPE_SKU                    = 3;
const    WAVE2_PARAMTYPE_DEVICETYPE             = 4;
const    WAVE2_PARAMTYPE_REGISTRATION_STATUS    = 5;
const    WAVE2_PARAMTYPE_PARTNUMBER             = 6;
const    WAVE2_PARAMTYPE_OPERATORLISTALL        = 7;
const    WAVE2_PARAMTYPE_OPERATORNAME           = 8;        // arg1=4 letter operator code
var     paramTypeStr                            = ["N/A", "FIRSTNAME", "OPERATOR_LIST", "SKU", "DEVICETYPE", "AZURE_REG_STATUS", "PART_NUMBER", "OPERATOR_LIST_ALL", "OPERATOR_NAME" ];
const   D2CMDG_SWUPDATE                         = 40;
const    WAVE2_IMAGETYPE_NU                     = 1;
const    WAVE2_IMAGETYPE_CU                     = 2;
const    WAVE2_IMAGETYPE_NU_PIC                 = 3;
const    WAVE2_IMAGETYPE_CU_PIC                 = 4;
const    WAVE2_IMAGETYPE_NU_BT                  = 5;
const    WAVE2_IMAGETYPE_CU_BT                  = 6;
const    WAVE2_IMAGETYPE_NU_ART                 = 7;
const    WAVE2_IMAGETYPE_CU_ART                 = 8;
const    WAVE2_IMAGETYPE_NU_EVM                 = 9;
const    WAVE2_IMAGETYPE_CU_EVM                 = 10;
const    WAVE2_IMAGETYPE_NU_SCFG                = 11;
const    WAVE2_IMAGETYPE_NU_UCFG                = 12;
const   D2CMDG_DEBUG_ADDFAKEFACTORYINFO         = 90;
const   D2CMSG_DEBUG_TECHDATASETPERIOD          = 92;                   //no payload

const   C2DMSG_REGISTER_OPERATOR_RSP            = 115;
const   C2DMSG_PARAM_GET_RSP                    = 120;
const   C2DMSG_DEVICE_CONFIG                    = 130;
const    WAVE2_CONFIGTYPE_ANTENNA               = 1;        // refer to ANTENNACONFIGTYPES for values
const    WAVE2_CONFIGTYPE_TECHDATAPERIOD        = 2;        // value is the period in seconds
const   C2DMSG_SWUPDATE_RSP                     = 140;


const   WAVE2_NOTIFICATION_ACTION_ASSOC         = 1;
const   WAVE2_NOTIFICATION_ACTION_DISASSOC      = 2;
const   WAVE2_STATUS_SUCCESS                    = 0;
const   WAVE2_STATUS_ERROR                      = 1;


var d2cHeaderLen                                = 0;
var tempCounter                                 = 0;
var c2dParamGetData                             = null;
var imageTypeStr                                = ["N/A", "NU", "CU", "NU_PIC", "CU_PIC", "NU_BT", "CU_BT", "NU_ART", "CU_ART", "NU_EVM", "CU_EVM", "NU_SCFG", "NU_UCFG"];

const   SwPnNuCu                                = "700N036-";
const   SwPnPic                                 = "700N040-";
const   SwPnBt                                  = "700N041-";
const   SwPnNuCfg                               = "700N037-";       // Both Secured and Unsecured
const   SwPnArt                                 = "800N003-";
const   SwPnEvm                                 = "800N004-";

var     s_CheckSwUpdateCount                    = 0;
var     iPollCount                              = 0;
var     iC2dCount                               = 0;




// RegisterCloudDev............................................................................................
function RegisterCloudDev( devId )
{
    if( (devId !== null) && (devId.length > 2) )
    {
        if( CFG_RUN_ON_SANDBOX )
        {
            PrintLog(1, "Azure: RegisterCloudDev(" + devId + ") with sandbox at " + sandboxName );
            platformName = sandboxName;
            sasHubKey    = sandboxSasHubKey;
        }
        else
        {
            PrintLog(1, "Azure: RegisterCloudDev(" + devId + ")" );
        }
        
        if( azureDeviceId.length == 0 )
        {
            azureDeviceId = devId.substring(2).toLowerCase();                       // Remove the 0x at the front and make lower case
            u8NuUniqueId[0] = parseInt( nxtyNuUniqueId.substring(2,4), 16 ); 
            u8NuUniqueId[1] = parseInt( nxtyNuUniqueId.substring(4,6), 16 ); 
            u8NuUniqueId[2] = parseInt( nxtyNuUniqueId.substring(6,8), 16 ); 
            u8NuUniqueId[3] = parseInt( nxtyNuUniqueId.substring(8,10), 16 ); 
            u8NuUniqueId[4] = parseInt( nxtyNuUniqueId.substring(10,12), 16 ); 
            u8NuUniqueId[5] = parseInt( nxtyNuUniqueId.substring(12,14), 16 ); 
            u8NuUniqueId[6] = parseInt( nxtyNuUniqueId.substring(14,16), 16 ); 
            u8NuUniqueId[7] = parseInt( nxtyNuUniqueId.substring(16), 16 ); 
            u8CuUniqueId[0] = parseInt( nxtyCuUniqueId.substring(2,4), 16 ); 
            u8CuUniqueId[1] = parseInt( nxtyCuUniqueId.substring(4,6), 16 ); 
            u8CuUniqueId[2] = parseInt( nxtyCuUniqueId.substring(6,8), 16 ); 
            u8CuUniqueId[3] = parseInt( nxtyCuUniqueId.substring(8,10), 16 ); 
            u8CuUniqueId[4] = parseInt( nxtyCuUniqueId.substring(10,12), 16 ); 
            u8CuUniqueId[5] = parseInt( nxtyCuUniqueId.substring(12,14), 16 ); 
            u8CuUniqueId[6] = parseInt( nxtyCuUniqueId.substring(14,16), 16 ); 
            u8CuUniqueId[7] = parseInt( nxtyCuUniqueId.substring(16), 16 ); 
     
        } 
        
        if( (platformName == null) || (blobPlatformName == null) || (sasHubKey == null) || (regIotFlag == null) )
        { 
            GetWssHubInfo(azureDeviceId);
        }
    }
    else
    {
        PrintLog(99, "Azure: RegisterCloudDev(devId=" + devId + ")  devId is bad." );
    }
    
}







// FillD2cHeader............................................................................................
//
//   Fill the 1st 16 bytes of u8AzureTxBuff[] with header info.   Note that the payload size 
//   will have to be filled in by the calling function... 
//
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  

function FillD2cHeader( hType, bNuId )
{
    var i              = 0;
    
    // d2cMsgHdr size = 16 bytes
    u8AzureTxBuff[i++] = APP_INTERFACE_VER;             // version
    u8AzureTxBuff[i++] = hType;                         // type  
    u8AzureTxBuff[i++] = 0;                             // reserved
    u8AzureTxBuff[i++] = 0;                             // reserved
    u8AzureTxBuff[i++] = 0;                             // payloadSize in bytes
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    
    if( bNuId )
    {
        u8AzureTxBuff[i++] = u8NuUniqueId[7];               // NU           
        u8AzureTxBuff[i++] = u8NuUniqueId[6];              
        u8AzureTxBuff[i++] = u8NuUniqueId[5];              
        u8AzureTxBuff[i++] = u8NuUniqueId[4];              
        u8AzureTxBuff[i++] = u8NuUniqueId[3];              
        u8AzureTxBuff[i++] = u8NuUniqueId[2];
        u8AzureTxBuff[i++] = u8NuUniqueId[1];
        u8AzureTxBuff[i++] = u8NuUniqueId[0];
    }
    else
    {
        u8AzureTxBuff[i++] = u8CuUniqueId[7];               // CU...           
        u8AzureTxBuff[i++] = u8CuUniqueId[6];              
        u8AzureTxBuff[i++] = u8CuUniqueId[5];              
        u8AzureTxBuff[i++] = u8CuUniqueId[4];              
        u8AzureTxBuff[i++] = u8CuUniqueId[3];              
        u8AzureTxBuff[i++] = u8CuUniqueId[2];
        u8AzureTxBuff[i++] = u8CuUniqueId[1];
        u8AzureTxBuff[i++] = u8CuUniqueId[0];
    }
    // End of header....................................
    
    d2cHeaderLen = i;
    return( i );
}


// SendCloudTechData............................................................................................
//
//  typedef struct
//  {
//      E16(MEASID)             measId;
//      short int               reserved;
//      int                     val;
//  } techDataType;
//  
//  typedef struct
//  {
//      unsigned int            numReports;
//      techDataType            report[1];      //variable size field as determined by numReports
//  } d2cMsg_Techdata;                          //Reference: D2CMSG_TECHDATA
//  
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  
//  typedef struct
//  {
//      d2cMsgHdr               hdr;
//      unsigned int            payload[1];     //variable-size field as determined by hdr.type
//  } d2cMsg;

function SendCloudTechData(dataText)
{
    if( sasDevKey.length != 0 )
    {
    
        var i              = 0;
        var j              = 0;
        var measId         = 0;
        var measVal        = 0;
        var iNumMeasActual = 0;
        
        PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudTechData( {" + dataText + "} )" );
    
        // Remove all ' characters...
        dataText = dataText.replace(/'/g, "" );
    
        var measList    = dataText.split(",");            // Build an array of meas values
        var iNumMeas    = measList.length;
    
        // d2cMsg....................................
        if( measList[0].substring(0,2) == "TC" )
        {
            // If "TC..." assume we are the CU... 
            i = FillD2cHeader( D2CMSG_TECHDATA, false );
        }
        else
        {
            i = FillD2cHeader( D2CMSG_TECHDATA, true );
        }
        
    
        // d2cMsg_Techdata
        u8AzureTxBuff[i++] = 0;               // numReports, i.e. number of measurements.
        u8AzureTxBuff[i++] = 0;
        u8AzureTxBuff[i++] = 0;
        u8AzureTxBuff[i++] = 0;
        
        for( j = 0; j < iNumMeas; j++ )
        {
            var measPair = measList[j].split(":");
            
            if( measPair.length == 2 )
            {
                measPair   = StandardizeValues(measPair);
                measId     = GetMeasId(measPair[0]);
                measVal    = parseInt(measPair[1]);
                
                // Special processing to handle the error code...
                if( (measId == 33280) && (measVal == 0) )
                {
                    // Clear all 12 error meas IDs.
                    for( ; measId < (33280 + 12); measId++ )
                    {
                        iNumMeasActual++;
                    
                        // Fill in the meas ID
                        u8AzureTxBuff[i++] = (measId >> 0);               
                        u8AzureTxBuff[i++] = (measId >> 8);
                        u8AzureTxBuff[i++] = 0;                 // reserved
                        u8AzureTxBuff[i++] = 0;
            
                        // Fill in the meas value
                        u8AzureTxBuff[i++] = (measVal >> 0);              
                        u8AzureTxBuff[i++] = (measVal >> 8);
                        u8AzureTxBuff[i++] = (measVal >> 16);
                        u8AzureTxBuff[i++] = (measVal >> 24);
                        PrintLog(1, "MeasList[" + j + "] = " + measList[j] + " id=" + measId + " val=" + measVal );
                    }

                
                }
                else
                {
                    if( measId == 33280 )
                    {
                        // Error code so set the associated measId.
                        measId += (measVal - 1);
                        measVal = 1;
                    }
                    
                    PrintLog(1, "MeasList[" + j + "] = " + measList[j] + " id=" + measId + " val=" + measVal );
                                
                    if( measId != -1 )
                    {
                        iNumMeasActual++;
                    
                        // Fill in the meas ID
                        u8AzureTxBuff[i++] = (measId >> 0);               
                        u8AzureTxBuff[i++] = (measId >> 8);
                        u8AzureTxBuff[i++] = 0;                     // reserved
                        u8AzureTxBuff[i++] = 0;
            
                        // Fill in the meas value
                        u8AzureTxBuff[i++] = (measVal >> 0);              
                        u8AzureTxBuff[i++] = (measVal >> 8);
                        u8AzureTxBuff[i++] = (measVal >> 16);
                        u8AzureTxBuff[i++] = (measVal >> 24);
                    }
                }
            }
        }


        var payloadSize = 4 + (iNumMeasActual * 8);             // iNumMeas size is 4 plus 8 bytes per meas.   
        u8AzureTxBuff[4] = (payloadSize >> 0);                  // payloadSize in bytes
        u8AzureTxBuff[5] = (payloadSize >> 8);
        u8AzureTxBuff[6] = (payloadSize >> 16);
        u8AzureTxBuff[7] = (payloadSize >> 24);

        u8AzureTxBuff[16] = (iNumMeasActual >> 0);              // numReports, i.e. number of measurements.
        u8AzureTxBuff[17] = (iNumMeasActual >> 8);
        u8AzureTxBuff[18] = (iNumMeasActual >> 16);
        u8AzureTxBuff[19] = (iNumMeasActual >> 24);

    
        GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
            
        var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/events?api-version=" + platformVer;
        var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };
    
        SendNorthBoundDataBinary( 
            "POST",
            myDataUrl,
            "application/octet-stream",
            u8AzureTxBuff,
            i,                              // length
            "",                             // response format
            myHeader,
            function(response) 
            {
                if( response != undefined )
                {
                    PrintLog( 1, "Azure: Response success: SendCloudTechData()...Response:" + JSON.stringify(response)  );
                }
                else
                {
                    PrintLog( 1, "Azure: Response success: SendCloudTechData()..." );
                }        
            },
            function(response) 
            {
                PrintLog( 99, "Azure: Response error: SendCloudTechData()..." + JSON.stringify(response) );
            }
        );
    
    
        

    }
    else
    {
        PrintLog( 99, "Azure: SendCloudTechData: SAS key not retrieved from cloud yet." );
    }
    
}


//.................................................................................................
function StartCloudPoll( pollTimeMs )
{
    PrintLog(1, "StartCloudPoll(" + pollTimeMs + ")" );        
    if( pollAzureIntervalHandle != null )
    {
        StopCloudPoll();
    }

    iPollCount = 0;
    pollAzureIntervalHandle = setInterval(SendCloudPoll, pollTimeMs );
    
    // Send one now....
    SendCloudPoll();
}


//.................................................................................................
function StopCloudPoll()
{
//    PrintLog(1, "StopCloudPoll()" );
    clearInterval(pollAzureIntervalHandle)
    pollAzureIntervalHandle = null;
    iPollCount = 0;
}

// SendCloudPoll............................................................................................
function SendCloudPoll()
{
    if( sasDevKey.length != 0 )
    {
        PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudPoll() Count=" + iPollCount );
        
        if( iPollCount > 100 )
        {
            PrintLog(1,  "Stop polling: Count=" + iPollCount );
            StopCloudPoll();
            return;    
        }
        
        iPollCount++;
    
        GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
            
        var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/devicebound?api-version=" + platformVer;
        var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };
    
        // Use XMLHttpRequest() instead of Ajax to receive binary data.   Very difficult to receive binary data with Ajax.    
        var xhttp = new XMLHttpRequest();
        xhttp.open("GET", myDataUrl, true);
        xhttp.responseType = 'arraybuffer';
        xhttp.setRequestHeader("Authorization", sasDevToken);
        xhttp.setRequestHeader("iothub-messageid", iMsgId++);
        xhttp.onreadystatechange = function() 
        {
            if( xhttp.readyState == 4 ) 
            {
                if( xhttp.status == 200 ) 
                {
                    if( this.response !== undefined ) 
                    {
                        PrintLog( 1, "Azure: Response success: SendCloudPoll()..." );

                        var u8EgressArray = new Uint8Array(this.response);
//                        PrintLog( 1, "Azure: Response success: SendCloudPoll()...status:" + xhttp.status + " typeof u8EgressArray=" + typeof(u8EgressArray) + " rspheader=" + xhttp.getResponseHeader("Etag") );

                        if( bFlushC2d == false )
                        {
                            if( iC2dCount > 0 )
                            {
                                iC2dCount--;
                                
                                if( iC2dCount == 0 )
                                {
                                    StopCloudPoll();
                                }
                            }
                        }
                        
                        ProcessAzureEgress(u8EgressArray);
                        SendCloudCompletePoll( xhttp.getResponseHeader("Etag") );
                    }                  
                }
                else if( xhttp.status == 204 ) 
                {
//                    PrintLog(1, "Azure: Response success: SendCloudPoll()...statusVal=" + xhttp.status + " : " + xhttp.statusText );
                    if( bFlushC2d )
                    {   
                        // Nothing in egress so stop flushing...
                        PrintLog(1, "Azure: Flushing C2D, no more messages so stop the flush." );
                        bFlushC2d = false;
                        StopCloudPoll();
                    }

                }
                else
                {
                    PrintLog( 99, "Azure: Response error: SendCloudPoll()...statusVal=" + xhttp.status + " : " + xhttp.statusText );
                }
            }
        };
        xhttp.send();

    
    }
    else
    {
        PrintLog( 99, "Azure: SendCloudPoll: SAS key not retrieved from cloud yet." );
    }
    
    
}



// SendCloudCompletePoll............................................................................................
function SendCloudCompletePoll(etag)
{
    if( sasDevKey.length != 0 )
    {
        GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
            
        var etagNoQuote = etag.replace(/"/g, "" );    
        var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/devicebound/" + etagNoQuote + "?api-version=" + platformVer;
   
        PrintLog( 1, "Azure: id:" + iMsgId + " SendCloudCompletePoll()" + myDataUrl );
    
        var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };
        
        SendNorthBoundDataBinary( 
            "DELETE",
            myDataUrl,
            "application/octet-stream",
            "",
            0,                              // length
            "",                             // response format
            myHeader,
            function(response) 
            {
                PrintLog( 1, "Azure: Response success: SendCloudCompletePoll()..." );
            },
            function(response) 
            {
                PrintLog( 99, "Azure: Response error: SendCloudCompletePoll()..." + JSON.stringify(response) );
            }
        );
    }
    else
    {
        PrintLog( 99, "Azure: SendCloudCompletePoll: SAS key not retrieved from cloud yet." );
    }
}



// ProcessAzureEgress............................................................................................
//
//  Handle the following types of C2D messages...
//    C2DMSG_REGISTER_OPERATOR_RSP          = 115;
//    C2DMSG_PARAM_GET_RSP                  = 120;
//    C2DMSG_DEVICE_CONFIG                  = 130
//    C2DMSG_SWUPDATE_RSP                   = 140;
//
//    typedef struct
//    {
//        unsigned char           version;              // [0] 1 byte
//        E8(C2DMSGTYPE)          type;                 // [1] 1 byte
//        unsigned char           reserved[2];          // [2] 2 bytes
//        unsigned int            payloadSize;          // [4] thru [7]  4 bytes
//        long long               uniqueID;             // [8] thru [15] 8 bytes
//    } c2dMsgHdr;
//    
//    typedef struct
//    {
//        c2dMsgHdr               hdr;                  // [0] to [15] 16 bytes
//        unsigned int            payload[1];           // [16] to [16 + payload size] variable-size field as determined by hdr.type
//    } c2dMsg;
//

function ProcessAzureEgress( u8RxData )
{
    var i;
    var j;
          
    if( u8RxData.length < 100 )
    {       
        PrintLog( 1, "Azure: ProcessAzureEgress() length:" + u8RxData.length + " stringify:" + JSON.stringify(u8RxData) );
    }
    else
    {       
        PrintLog( 1, "Azure: ProcessAzureEgress() length:" + u8RxData.length + " stringify 1st 100 bytes:" + JSON.stringify(u8RxData.subarray(0,100)) );
    }
    
    var c2dVer         = u8RxData[0];
    var c2dType        = u8RxData[1];
    var c2dPayloadSize = (u8RxData[7] << 24) | (u8RxData[6] << 16) | (u8RxData[5] << 8)  | u8RxData[4];
//    PrintLog(1, "Azure: ProcessAzureEgress()  Ver=" + c2dVer + " Type=" + c2dType + " Payload Size=" + c2dPayloadSize );
    
    if( bFlushC2d )
    {
        PrintLog(1, "Azure: ProcessAzureEgress()  Ver=" + c2dVer + " Type=" + c2dType + " Payload Size=" + c2dPayloadSize );
        PrintLog(1, "Azure: Flushing C2D, do not process egress message." );
        return;
    }
    
    if( c2dType == C2DMSG_REGISTER_OPERATOR_RSP )
    {
        //    typedef struct
        //    {
        //        varstr                  regDataFromOp;        [16] +
        //    } c2dMsg_Register_Operator_Rsp;                 //Reference: C2DMSG_REGISTER_OPERATOR_RSP
        //
        // If 256 byte payload has any data then send directly to Cel-Fi, if not then send regOpForce:true.
        if( c2dPayloadSize && (u8RxData[16] || u8RxData[17]) )
        {
            var c2dParamLen       = (u8RxData[17] << 8)  | u8RxData[16];
            
            myRegOpForce = "false";
            
            // Convert the payload to string and send...
            myRegDataFromOp = bytesToString( u8RxData.subarray(18, 18 + c2dParamLen) );
            PrintLog(1, "Azure: ProcessAzureEgress(C2DMSG_REGISTER_OPERATOR_RSP)  MsgLen=" + u8RxData.length + " Param Len=" + c2dParamLen + " send payload string to Cel-Fi =" + myRegDataFromOp );
        } 
        else
        {
            myRegOpForce = "true";
            PrintLog(1, "Azure: ProcessAzureEgress(C2DMSG_REGISTER_OPERATOR_RSP)  MsgLen=" + u8RxData.length + " No data in payload: send regOpForce:true to Cel-Fi" );
        }
    }
    else if( c2dType == C2DMSG_PARAM_GET_RSP )
    {
    
        //    typedef struct
        //    {
        //        unsigned int            status;                   // [16] thru [19] 4 bytes
        //        E32(PARAMTYPES)         param;                    // [20] thru [23] 4 bytes
        //        varstr                  value;                    // [24] thru [25] len, [26]+ data
        //    } c2dMsg_Param_Get_Rsp;                               //Reference: C2DMSG_PARAM_GET_RSP
    
        if( c2dPayloadSize )
        {
            var c2dParamGetStatus = (u8RxData[19] << 24) | (u8RxData[18] << 16) | (u8RxData[17] << 8)  | u8RxData[16];
            var c2dParam          = (u8RxData[23] << 24) | (u8RxData[22] << 16) | (u8RxData[21] << 8)  | u8RxData[20];
            var c2dParamLen       = (u8RxData[25] << 8)  | u8RxData[24];
            
//            PrintLog(1, "Azure: ProcessAzureEgress(C2DMSG_PARAM_GET_RSP)  status=" + c2dParamGetStatus + " c2dParam=" + c2dParam + " c2dParamLen=" + c2dParamLen );
            // If the status is success then use the data...
            if( c2dParamGetStatus == WAVE2_STATUS_SUCCESS )
            {
                c2dParamGetData = bytesToString( u8RxData.subarray(26, 26 + c2dParamLen) );
                
                var tempParamType = c2dParam;
                if( c2dParam < paramTypeStr.length )
                {
                    tempParamType = paramTypeStr[c2dParam];
                }
                PrintLog(1, "Azure: ProcessAzureEgress(C2DMSG_PARAM_GET_RSP)  parma=" + tempParamType + " len=" + c2dParamLen + " data=" + c2dParamGetData );
                
                if( c2dParam == WAVE2_PARAMTYPE_FIRSTNAME )
                {
                    // Make sure that we have something...
                    if( c2dParamGetData.length )
                    {
                        guiUserFirstName = szRegFirstName = c2dParamGetData;
                        
                        // See if stored on phone yet...
                        if( window.localStorage.getItem(nxtyCuUniqueId + "firstName") === null ) 
                        {
                            window.localStorage.setItem(nxtyCuUniqueId + "firstName", szRegFirstName);
                        }
                    }
                }
                else if( c2dParam == WAVE2_PARAMTYPE_OPERATORLIST )
                {
                    // Make sure that we have something...
                    if( c2dParamGetData.length )
                    {
                        szOperatorSkus = c2dParamGetData;
                        
                        if( szOperatorCodeNames != null )
                        {
                            GenerateOperatorList();
                        }
                    }
                }
                else if( c2dParam == WAVE2_PARAMTYPE_REGISTRATION_STATUS )
                {
                    // Make sure that we have something...
                    if( c2dParamGetData.length )
                    {
                        szCloudRegStatus = c2dParamGetData;
                    }
                }
                else if( c2dParam == WAVE2_PARAMTYPE_PARTNUMBER )
                {
                    // Make sure that we have something...
                    if( c2dParamGetData.length )
                    {
                        ProcessSku(c2dParamGetData);
                        
                        // Store the SKU on the phone if new sku format, i.e. 20 bytes...
                        if( mySku.length == 20 )
                        {
                            PrintLog( 1, "  Store SKU on phone to get later..." );
                            window.localStorage.setItem(nxtyCuUniqueId, c2dParamGetData);
                        }
                    }
                }
                else if( c2dParam == WAVE2_PARAMTYPE_OPERATORLISTALL )
                {
                    // Make sure that we have something...
                    if( c2dParamGetData.length )
                    {
                        // looks like: "A1AT:A1 Telecom Austria AG,AEBR:Accenture Brazil,ALSA:Aljawal STC Saudi Arabia,ATUS:AT&T"
                        szOperatorCodeNames = c2dParamGetData;  
                        window.localStorage.setItem( "szOperatorCodeNames", szOperatorCodeNames );
                    }
                }
                else if( c2dParam == WAVE2_PARAMTYPE_OPERATORNAME )
                {
                    // Make sure that we have something...
                    if( c2dParamGetData.length )
                    {
                        // Response looks like: "ATUS:AT&T"
                        guiOperatorCode = c2dParamGetData.substring(0,4);      // 4 digit code
                            
                        var textIdx = c2dParamGetData.search(":");
                        if( textIdx != -1 )
                        {
                            guiOperator = c2dParamGetData.substring(textIdx+1);
                            window.localStorage.setItem(nxtyCuUniqueId + "guiOperatorCode", guiOperatorCode);
                            window.localStorage.setItem(nxtyCuUniqueId + "guiOperator",     guiOperator);                        
                        }
                        
                        PrintLog(1, "Azure: Operator Code: " + guiOperatorCode + "  Operator: " + guiOperator );
                    }
                }
                
                
                
                
                
                
                
            }
            else
            {
                PrintLog(1, "Azure: ProcessAzureEgress(C2DMSG_PARAM_GET_RSP)  status=FAIL c2dParam=" + c2dParam + " c2dParamLen=" + c2dParamLen );
            }
        }
    }
    
    
    else if( c2dType == C2DMSG_DEVICE_CONFIG )
    {
        //    typedef struct
        //    {
        //        E32(CONFIGTYPES)        config;               // [16] thru [19], 4 bytes
        //        int                     value;                // [20] thru [23], 4 bytes
        //    } c2dMsg_Device_Config;                           // Reference: C2DMSG_DEVICE_CONFIG
    
        if( c2dPayloadSize )
        {
            var c2dParamConfig    = (u8RxData[19] << 24) | (u8RxData[18] << 16) | (u8RxData[17] << 8)  | u8RxData[16];
            var c2dParamValue     = (u8RxData[23] << 24) | (u8RxData[22] << 16) | (u8RxData[21] << 8)  | u8RxData[20];
            
            PrintLog(1, "Azure: ProcessAzureEgress(C2DMSG_DEVICE_CONFIG)  config=" + c2dParamConfig + " value=" + c2dParamValue );
            
            // If the status is success then use the data...
            if( c2dParamConfig == WAVE2_CONFIGTYPE_ANTENNA )
            {
            }
            else if( c2dParamConfig == WAVE2_CONFIGTYPE_TECHDATAPERIOD )
            {
                if( c2dParamValue >= 0 )
                {
                    PrintLog(1, "Azure: ProcessAzureEgress(C2DMSG_DEVICE_CONFIG)  set tech update rate to " + c2dParamValue + " sec." );
                    sendTechToCloudPeriodSec = c2dParamValue;
                }
            }
            
        }
    }
    
    
    
    else if( c2dType == C2DMSG_SWUPDATE_RSP )
    {
        //    typedef struct
        //    {
        //      unsigned int            numFiles;           // [16] thru [19], 4 bytes
        //      swUpdateFileType        files[1];           // variable-size field as determined by numFiles
        //    } c2dMsg_Swupdate_Rsp;                        // Reference: C2DMSG_SWUPDATE_RSP
        if( c2dPayloadSize )
        {
            var c2dNumFiles = (u8RxData[19] << 24) | (u8RxData[18] << 16) | (u8RxData[17] << 8)  | u8RxData[16];
            
            PrintLog(1, "Azure: ProcessAzureEgress(C2DMSG_SWUPDATE_RSP)  numFiles=" + c2dNumFiles );
            
            if( c2dNumFiles > 0 )
            {
                i = 20;
                var c2dLen;
                
                
                //    typedef struct
                //    {
                //      E8(IMAGETYPES)          imagetype;
                //      varstr                  dirname;            // Part number:  i.e. 700N036-005-023
                //      varstr                  filename;           // i.e. WuExecutable.sec/Pic.bin etc. (for SCFG, not name but actual 388 bytes of binary data.)
                //      varstr                  sas;
                //    } swUpdateFileType;
                for( j = 0; j < c2dNumFiles; j++ )
                {
                    var c2dImageType =  u8RxData[i++];
                    var c2dLen       =  (u8RxData[i+1] << 8) | u8RxData[i];
                        i           += 2;
                    var c2dDirData   = bytesToString( u8RxData.subarray(i, i + c2dLen) );    
                        i           += c2dLen;
                    c2dLen           =  (u8RxData[i+1] << 8) | u8RxData[i];
                        i           += 2;
                                    
                    if( c2dImageType == WAVE2_IMAGETYPE_NU_SCFG )
                    {
                        // The file contains the binary data...
                        nxtySwVerNuSCfgCld = FixCloudVer(c2dDirData);
                        fileNuSCfgCldId    = new Uint8Array(c2dLen);
                        
                        for( k = 0; k < c2dLen; k++ )
                        {
                            fileNuSCfgCldId[k] = u8RxData[i++];                 // Should be 388 byte binary file.    
                        }
                        PrintLog(1, "  Azure: ImageType=" + imageTypeStr[c2dImageType] + " dirName=" + c2dDirData + " fileLen=" + c2dLen );
                        
                        // Bump past the SAS which should be 0...
                        c2dLen =  (u8RxData[i+1] << 8) | u8RxData[i];
                        i     += 2;
                        i     += c2dLen;
                    }
                    else
                    { 
                        var c2dFileData  = bytesToString( u8RxData.subarray(i, i + c2dLen) );                    
                            i           += c2dLen;
                            c2dLen       =  (u8RxData[i+1] << 8) | u8RxData[i];
                            i           += 2;
                        var c2dSasData   = bytesToString( u8RxData.subarray(i, i + c2dLen) );                    
                            i           += c2dLen;
                            
                        var fileId = c2dDirData + "/" + c2dFileData + c2dSasData;    
                        PrintLog(1, "  Azure: ImageType=" + imageTypeStr[c2dImageType] + " dirName=" + c2dDirData + " fileName=" + c2dFileData + " sas=" + c2dSasData + " fileId=" + fileId );
                        
                        
                        if( c2dImageType == WAVE2_IMAGETYPE_NU )
                        {
                            nxtySwVerNuCfCld = FixCloudVer(c2dDirData);
                            fileNuCfCldId    = fileId;
                        }
                        else if( c2dImageType == WAVE2_IMAGETYPE_CU )
                        {
                            nxtySwVerCuCfCld = FixCloudVer(c2dDirData);
                            fileCuCfCldId    = fileId;
                        }
                        else if( c2dImageType == WAVE2_IMAGETYPE_NU_PIC )
                        {
                            nxtySwVerNuPicCld = FixCloudVer(c2dDirData);
                            fileNuPicCldId    = fileId;
                        }
                        else if( c2dImageType == WAVE2_IMAGETYPE_CU_PIC )
                        {
                            nxtySwVerCuPicCld = FixCloudVer(c2dDirData);
                            fileCuPicCldId    = fileId;
                        }
                        else if( c2dImageType == WAVE2_IMAGETYPE_NU_BT )
                        {
                        }
                        else if( c2dImageType == WAVE2_IMAGETYPE_CU_BT )
                        {
                            nxtySwVerCuBtCld = FixCloudVer(c2dDirData);
                            fileBtCldId    = fileId;
                        }
                        else if( c2dImageType == WAVE2_IMAGETYPE_NU_ART )
                        {
                            nxtySwVerNuArtCld = FixCloudVer(c2dDirData);
                            fileNuArtCldId    = fileId;
                        }
                        else if( c2dImageType == WAVE2_IMAGETYPE_CU_ART )
                        {
                            nxtySwVerCuArtCld = FixCloudVer(c2dDirData);
                            fileCuArtCldId    = fileId;
                        }
                        else if( c2dImageType == WAVE2_IMAGETYPE_NU_EVM )
                        {
                            nxtySwVerNuEvmCld = FixCloudVer(c2dDirData);
                            fileNuEvmCldId    = fileId;
                        }
                        else if( c2dImageType == WAVE2_IMAGETYPE_CU_EVM )
                        {
                            nxtySwVerCuEvmCld = FixCloudVer(c2dDirData);  
                            fileCuEvmCldId    = fileId;
                        }
                        else if( c2dImageType == WAVE2_IMAGETYPE_NU_UCFG )
                        {
                            nxtySwVerNuUCfgCld = FixCloudVer(c2dDirData);
                            fileNuUCfgCldId    = fileId;
                        }


                    }
                    
                    
                        
                }   // end of for
                
                // Indiate that we have some files...
                bGotUpdateAvailableRspFromCloud     = true;
                isUpdateAvailableFromCloud          = true;
                bGotPackageAvailableRspFromCloud    = true;                
                
             }
             else
             {
                // No files....
                bGotUpdateAvailableRspFromCloud     = true;
                isUpdateAvailableFromCloud          = false;
                bGotPackageAvailableRspFromCloud    = false;                
             }
        }
        
        PrintLog(1, "  Azure: bGotUpdateAvailableRspFromCloud=" + bGotUpdateAvailableRspFromCloud + " isUpdateAvailableFromCloud=" + isUpdateAvailableFromCloud + " bGotPackageAvailableRspFromCloud=" + bGotPackageAvailableRspFromCloud );
        
    }
    else
    {
        PrintLog(99, "Azure: ProcessAzureEgress(C2DMSG_UNKNOWN_RSP)  MsgLen=" + u8RxData.length + " Type=" + c2dType + " Payload Size=" + c2dPayloadSize );
    }

}


// SendCloudAssociateSystem............................................................................................
//
//  typedef struct
//  {
//      varstr                  nameStr;
//      varstr                  valStr;
//  } systemAttribType;
//  
//  typedef struct
//  {
//      unsigned int            siteID;
//      long long               systemID;
//      unsigned char           systemIPAddress[WAVE2_SYSIPADDR_LEN];   // 16
//      unsigned int            numSystemAttrib;
//      systemAttribType        systemAttrib[1];//variable size field as determined by numSystemAttrib
//  } d2cMsg_Register_Assoc_System;             //Reference: D2CMSG_REGISTER_ASSOC_SYSTEM
//  
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  
//  typedef struct
//  {
//      d2cMsgHdr               hdr;
//      unsigned int            payload[1];     //variable-size field as determined by hdr.type
//  } d2cMsg;


function SendCloudAssociateSystem()
{
    var i              = 0;
    
    PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudAssociateSystem()" );
    
    if( sasDevKey.length == 0 )
    {
        PrintLog( 99, "Azure: SendCloudAssociateSystem: SAS key not retrieved from cloud yet." );
        return;
    }
    

    // d2cMsg....................................
    i = FillD2cHeader( D2CMSG_REGISTER_ASSOC_SYSTEM, true );
    
    // payload assoc system
    u8AzureTxBuff[i++] = 0;                             // siteID
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = u8NuUniqueId[7];               // systemID same as uniqueID in header.            
    u8AzureTxBuff[i++] = u8NuUniqueId[6];              
    u8AzureTxBuff[i++] = u8NuUniqueId[5];              
    u8AzureTxBuff[i++] = u8NuUniqueId[4];              
    u8AzureTxBuff[i++] = u8NuUniqueId[3];              
    u8AzureTxBuff[i++] = u8NuUniqueId[2];
    u8AzureTxBuff[i++] = u8NuUniqueId[1];
    u8AzureTxBuff[i++] = u8NuUniqueId[0];
    u8AzureTxBuff[i++] = 0;                             // systemIPAddress[16]
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;                             // numSystemAttrib
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;
    u8AzureTxBuff[i++] = 0;

    // Fill in the payload size, assume size is less than 256, i.e. 1 byte.    
    u8AzureTxBuff[4] = i - d2cHeaderLen;          // Current number of bytes minus 16-byte header.
    
   

    GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
        
    var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/events?api-version=" + platformVer;
    var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };

     SendNorthBoundDataBinary( 
        "POST",
        myDataUrl,
        "application/octet-stream",
        u8AzureTxBuff,
        i,                              // length
        "",                             // response format
        myHeader,
        function(response) 
        {
            PrintLog( 1, "Azure: Response success: SendCloudAssociateSystem()..."  );        
        },
        function(response) 
        {
            PrintLog( 99, "Azure: Response error: SendCloudAssociateSystem()..." + JSON.stringify(response) );
        }
    );
}


// SendCloudAssociateBoards............................................................................................
//
//  typedef struct
//  {
//      long long               systemID;
//      long long               boardUniqueID;
//      unsigned int            portNum;
//      varstr                  name;
//  } d2cMsg_Register_Assoc_Board;              //Reference: D2CMSG_REGISTER_ASSOC_BOARD
//
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  
//  typedef struct
//  {
//      d2cMsgHdr               hdr;
//      unsigned int            payload[1];     //variable-size field as determined by hdr.type
//  } d2cMsg;


function SendCloudAssociateBoards()
{
    var i              = 0;
    var j              = 0;
    var iNumBoards     = 0;
    
    if( bCnxToOneBoxNu )
    {
        iNumBoards     = 1;
    }
    else
    {
        iNumBoards     = 2;
    }
    
    PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudAssociateBoards(" + iNumBoards + ")" );
    
    if( sasDevKey.length == 0 )
    {
        PrintLog( 99, "Azure: SendCloudAssociateBoards: SAS key not retrieved from cloud yet." );
        return;
    }
    
    
    for( var iBoard = 0; iBoard < iNumBoards; iBoard++ )
    {
        
        // d2cMsg....................................
        i = FillD2cHeader( D2CMSG_REGISTER_ASSOC_BOARD, true );

        // payload assoc board 
        u8AzureTxBuff[i++] = u8NuUniqueId[7];               // systemID same as uniqueID in header.            
        u8AzureTxBuff[i++] = u8NuUniqueId[6];              
        u8AzureTxBuff[i++] = u8NuUniqueId[5];              
        u8AzureTxBuff[i++] = u8NuUniqueId[4];              
        u8AzureTxBuff[i++] = u8NuUniqueId[3];              
        u8AzureTxBuff[i++] = u8NuUniqueId[2];
        u8AzureTxBuff[i++] = u8NuUniqueId[1];
        u8AzureTxBuff[i++] = u8NuUniqueId[0];
        
        if( iBoard == 0 )
        {
            u8AzureTxBuff[i++] = u8NuUniqueId[7];               // board uniqueID.            
            u8AzureTxBuff[i++] = u8NuUniqueId[6];              
            u8AzureTxBuff[i++] = u8NuUniqueId[5];              
            u8AzureTxBuff[i++] = u8NuUniqueId[4];              
            u8AzureTxBuff[i++] = u8NuUniqueId[3];              
            u8AzureTxBuff[i++] = u8NuUniqueId[2];
            u8AzureTxBuff[i++] = u8NuUniqueId[1];
            u8AzureTxBuff[i++] = u8NuUniqueId[0];
            u8AzureTxBuff[i++] = 0;                             // port number
            u8AzureTxBuff[i++] = 0;
            u8AzureTxBuff[i++] = 0;
            u8AzureTxBuff[i++] = 0;
            
            // NU name....
            var u8NuRsp = stringToBytes("NU");
            u8AzureTxBuff[i++] = (u8NuRsp.length >> 0);         // Add the 2 byte length
            u8AzureTxBuff[i++] = (u8NuRsp.length >> 8);
            
            for( j = 0; j < u8NuRsp.length; j++ )
            {
                u8AzureTxBuff[i++] = u8NuRsp[j];
            }
        }
        else
        {
            u8AzureTxBuff[i++] = u8CuUniqueId[7];               // board uniqueID.            
            u8AzureTxBuff[i++] = u8CuUniqueId[6];              
            u8AzureTxBuff[i++] = u8CuUniqueId[5];              
            u8AzureTxBuff[i++] = u8CuUniqueId[4];              
            u8AzureTxBuff[i++] = u8CuUniqueId[3];              
            u8AzureTxBuff[i++] = u8CuUniqueId[2];
            u8AzureTxBuff[i++] = u8CuUniqueId[1];
            u8AzureTxBuff[i++] = u8CuUniqueId[0];
            u8AzureTxBuff[i++] = 1;                             // CU port number = 1
            u8AzureTxBuff[i++] = 0;
            u8AzureTxBuff[i++] = 0;
            u8AzureTxBuff[i++] = 0;
            
            // CU name....
            var u8CuRsp = stringToBytes("CU");
            u8AzureTxBuff[i++] = (u8CuRsp.length >> 0);         // Add the 2 byte length
            u8AzureTxBuff[i++] = (u8CuRsp.length >> 8);
            
            for( j = 0; j < u8CuRsp.length; j++ )
            {
                u8AzureTxBuff[i++] = u8CuRsp[j];
            }
        }
        
        // Fill in the payload size, assume size is less than 256, i.e. 1 byte.    
        u8AzureTxBuff[4] = i - d2cHeaderLen;          // Current number of bytes minus 16-byte header.
        
    
        GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
            
        var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/events?api-version=" + platformVer;
        var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };
       
    
         SendNorthBoundDataBinary( 
            "POST",
            myDataUrl,
            "application/octet-stream",
            u8AzureTxBuff,
            i,                              // length
            "",                             // response format
            myHeader,
            function(response) 
            {
                PrintLog( 1, "Azure: Response success: SendCloudAssociateBoards()..."  );        
            },
            function(response) 
            {
                PrintLog( 99, "Azure: Response error: SendCloudAssociateBoards()..." + JSON.stringify(response) );
            }
        );
    }
}


// SendCloudAssociatePush............................................................................................
//
//  typedef struct
//  {
//      long long               systemID;
//      unsigned int            action;         // WAVE2_NOTIFICATION_ACTION_ASSOC or WAVE2_NOTIFICATION_ACTION_DISASSOC
//      varstr                  platform;       // GCM or APN
//      varstr                  key;
//  } d2cMsg_Register_Assoc_Notification;       // Reference: D2CMSG_REGISTER_ASSOC_NOTIFICATION
//  
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  
//  typedef struct
//  {
//      d2cMsgHdr               hdr;
//      unsigned int            payload[1];     //variable-size field as determined by hdr.type
//  } d2cMsg;


function SendCloudAssociatePush( platform, key )
{
    var i              = 0;
    var j              = 0;
    
    if( sasDevKey.length != 0 )
    {
        
        PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudAssociatePush(" + platform + ")" );
        
        // d2cMsg....................................
        i = FillD2cHeader( D2CMSG_REGISTER_ASSOC_NOTIFICATION, true );
        
        // payload assoc notification 
        u8AzureTxBuff[i++] = u8NuUniqueId[7];               // systemID same as uniqueID in header.            
        u8AzureTxBuff[i++] = u8NuUniqueId[6];              
        u8AzureTxBuff[i++] = u8NuUniqueId[5];              
        u8AzureTxBuff[i++] = u8NuUniqueId[4];              
        u8AzureTxBuff[i++] = u8NuUniqueId[3];              
        u8AzureTxBuff[i++] = u8NuUniqueId[2];
        u8AzureTxBuff[i++] = u8NuUniqueId[1];
        u8AzureTxBuff[i++] = u8NuUniqueId[0];
        u8AzureTxBuff[i++] = (WAVE2_NOTIFICATION_ACTION_ASSOC >> 0);                  // action
        u8AzureTxBuff[i++] = (WAVE2_NOTIFICATION_ACTION_ASSOC >> 8);
        u8AzureTxBuff[i++] = (WAVE2_NOTIFICATION_ACTION_ASSOC >> 16);
        u8AzureTxBuff[i++] = (WAVE2_NOTIFICATION_ACTION_ASSOC >> 24);
    
        // platform........................................................................           
        var u8Temp = stringToBytes(platform);
        u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
        u8AzureTxBuff[i++] = (u8Temp.length >> 8);
        
        
        for( j = 0; j < u8Temp.length; j++ )
        {
            u8AzureTxBuff[i++] = u8Temp[j];
        }
            
        // key........................................................................           
        u8Temp = stringToBytes(key);
        u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
        u8AzureTxBuff[i++] = (u8Temp.length >> 8);
        
        for( j = 0; j < u8Temp.length; j++ )
        {
            u8AzureTxBuff[i++] = u8Temp[j];
        }
            
    
        var payloadSize = i - d2cHeaderLen;                 // Current number of bytes minus 16-byte header.
        u8AzureTxBuff[4] = (payloadSize >> 0);              // payloadSize in bytes
        u8AzureTxBuff[5] = (payloadSize >> 8);
        u8AzureTxBuff[6] = (payloadSize >> 16);
        u8AzureTxBuff[7] = (payloadSize >> 24);
        
    
        GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
            
        var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/events?api-version=" + platformVer;
        var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };
       
    
         SendNorthBoundDataBinary( 
            "POST",
            myDataUrl,
            "application/octet-stream",
            u8AzureTxBuff,
            i,                              // length
            "",                             // response format
            myHeader,
            function(response) 
            {
                PrintLog( 1, "Azure: Response success: SendCloudAssociatePush()..."  );        
            },
            function(response) 
            {
                PrintLog( 99, "Azure: Response error: SendCloudAssociatePush()..." + JSON.stringify(response) );
            }
        );
    }
    else
    {
        PrintLog( 99, "Azure: SendCloudAssociatePush: SAS key not retrieved from cloud yet." );
    }
}


// SendCloudOperatorRegistrationInfo............................................................................................
//
//  This function is used to send operator registration information, i.e. first name/last name etc, to the cloud.
//  The operator registration information is contained within the site structure in the cloud.
//
//   Data items for site are:
//
//      SiteName              (Sent with data as:  SKU-SN)
//      *SiteOwnerFirstName
//      *SiteOwnerLastName
//      *Address1
//      *Address2
//      *City
//      *State 
//      *Country
//      *Zip
//      SitePlan
//      SiteCoveragePlan
//      Latitude
//      Longitude
//      *Phone
//
//     * used for operator registration
//       Note that SiteName will also be filled in with SKU-SN as an asset.
//
//
//  typedef struct
//  {
//      varstr                  nameStr;
//      varstr                  valStr;
//  } siteAttribType;
//  
//  typedef struct
//  {
//      unsigned int            siteID;         // Use 0 to automatically create or resolve based on uniqueID in header. Existing siteID can be used to append/edit site attributes.
//      unsigned int            numSiteAttrib;
//      siteAttribType          siteAttrib[1];  // variable size field as determined by numSiteAttrib  
//  } d2cMsg_Register_NewSite;                  // Reference: D2CMSG_REGISTER_NEWSITE
//
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  
//  typedef struct
//  {
//      d2cMsgHdr               hdr;
//      unsigned int            payload[1];     //variable-size field as determined by hdr.type
//  } d2cMsg;


function SendCloudOperatorRegistrationInfo(bNewSite, firstName, lastName, addr_1, addr_2, city, state, zip, country, phone, gpsLat, gpsLong )
{
    var i              = 0;
    var j              = 0;
    var k              = 0;
    var iNum           = 0;
    
    PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudOperatorRegistrationInfo(" + bNewSite + ", "+ firstName + ", " + lastName + ", " + addr_1 + ", " + addr_2 + ", " + city + ", " + state + ", " + zip + ", " + country + ", " + phone + ", " + gpsLat + ", " + gpsLong + ")" );
    
    if( sasDevKey.length == 0 )
    {
        PrintLog( 99, "Azure: SendCloudOperatorRegistrationInfo: SAS key not retrieved from cloud yet." );
        return;
    }
    
    
    // d2cMsg....................................
    if( bNewSite )
    {
        i = FillD2cHeader( D2CMSG_REGISTER_NEWSITE, true );
    }
    else
    {
        i = FillD2cHeader( D2CMSG_REGISTER_EDITSITE, true );
    }

    // payload..............
    u8AzureTxBuff[i++] = 0;                             // siteID.  Use 0 to force cloud to resolve.            
    u8AzureTxBuff[i++] = 0;              
    u8AzureTxBuff[i++] = 0;              
    u8AzureTxBuff[i++] = 0;              


    var tempSite = mySku + "-" + mySn;        
    var attName = ["SiteName", "SiteOwnerFirstName", "SiteOwnerLastName", "Address1", "Address2", "City", "State", "Country", "Zip", "Phone", "Latitude", "Longitude" ];
    var attVal  = [ tempSite,   firstName,            lastName,            addr_1,     addr_2,     city,   state,   country,   zip,   phone,   gpsLat,     gpsLong ];

    // payload new site 
    u8AzureTxBuff[i++] = attName.length;              // numSiteAttrib.            
    u8AzureTxBuff[i++] = 0;              
    u8AzureTxBuff[i++] = 0;              
    u8AzureTxBuff[i++] = 0;              

    for( k = 0; k < attName.length; k++ )
    {        
        // Only send if there is data...
        if( attVal[k].length )
        {
            iNum++;
            
            var u8Temp = stringToBytes(attName[k]);
            u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
            u8AzureTxBuff[i++] = (u8Temp.length >> 8);
            for( j = 0; j < u8Temp.length; j++ )
            {
                u8AzureTxBuff[i++] = u8Temp[j];
            }
          
          
            u8Temp = stringToBytes(attVal[k]);
            u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
            u8AzureTxBuff[i++] = (u8Temp.length >> 8);
            for( j = 0; j < u8Temp.length; j++ )
            {
                u8AzureTxBuff[i++] = u8Temp[j];
            }
        }
    }
  
    // Reset the number...
    u8AzureTxBuff[20] = iNum;              // numSiteAttrib.            

    
    // Fill in the payload size...........
    var payloadSize = i - d2cHeaderLen;             // Current number of bytes minus 16-byte header.
    u8AzureTxBuff[4] = (payloadSize >> 0);          // payloadSize in bytes
    u8AzureTxBuff[5] = (payloadSize >> 8);
    u8AzureTxBuff[6] = (payloadSize >> 16);
    u8AzureTxBuff[7] = (payloadSize >> 24);

    GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
        
    var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/events?api-version=" + platformVer;
    var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };
   

     SendNorthBoundDataBinary( 
        "POST",
        myDataUrl,
        "application/octet-stream",
        u8AzureTxBuff,
        i,                              // length
        "",                             // response format
        myHeader,
        function(response) 
        {
            PrintLog( 1, "Azure: Response success: SendCloudOperatorRegistrationInfo()..."  );        
        },
        function(response) 
        {
            PrintLog( 99, "Azure: Response error: SendCloudOperatorRegistrationInfo()..." + JSON.stringify(response) );
        }
    );
}



// SendCloudOperatorRegistration............................................................................................
//
//  This function is used to send operator registration trigger to the cloud.
//  The data should have already been sent in the SendCloudOperatorRegistrationInfo() message and tech mode data.
//
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  
//  typedef struct
//  {
//      d2cMsgHdr               hdr;            // No payload associated with this message.
//  } d2cMsg;
//
function SendCloudOperatorRegistration()
{
    var i              = 0;
    
    PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudOperatorRegistration()" );
    
    if( sasDevKey.length == 0 )
    {
        PrintLog( 99, "Azure: SendCloudOperatorRegistration: SAS key not retrieved from cloud yet." );
        return;
    }
    
    
    // d2cMsg....................................
    i = FillD2cHeader( D2CMSG_REGISTER_OPERATOR, true );

    GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
        
    var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/events?api-version=" + platformVer;
    var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };
   

     SendNorthBoundDataBinary( 
        "POST",
        myDataUrl,
        "application/octet-stream",
        u8AzureTxBuff,
        i,                              // length
        "",                             // response format
        myHeader,
        function(response) 
        {
            PrintLog( 1, "Azure: Response success: SendCloudOperatorRegistration()..."  );        
        },
        function(response) 
        {
            PrintLog( 99, "Azure: Response error: SendCloudOperatorRegistration()..." + JSON.stringify(response) );
        }
    );
}


// SendCloudParamGet............................................................................................
//
//  This function is used to request a parameter value from the cloud.
//  
//  enum PARAMTYPES
//  {
//    WAVE2_PARAMTYPE_FIRSTNAME               = 1,
//    WAVE2_PARAMTYPE_OPERATORLIST,
//    WAVE2_PARAMTYPE_SKU,
//    WAVE2_PARAMTYPE_DEVICETYPE,
//    WAVE2_PARAMTYPE_REGISTRATION_STATUS,
//    WAVE2_PARAMTYPE_PARTNUMBER,             // get
//    WAVE2_PARAMTYPE_OPERATORLISTALL,        // get
//    WAVE2_PARAMTYPE_OPERATORNAME,           // get

//  };
//  
//  typedef struct
//  {
//      E32(PARAMTYPES)         param;
//      varstr                  optarg1;
//      varstr                  optarg2;
//      varstr                  optarg3;
//  } d2cMsg_Param_Get;                         //Reference: D2CMSG_PARAM_GET
//
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  
//  typedef struct
//  {
//      d2cMsgHdr               hdr;            // No payload associated with this message.
//  } d2cMsg;
//
function SendCloudParamGet(myParam, myStrArg1, myStrArg2, myStrArg3)
{
    var i              = 0;
    var j              = 0;
    
    PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudParamGet(" + paramTypeStr[myParam] + ", arg1=" + myStrArg1 + ", arg2=" + myStrArg2 + ", arg3=" + myStrArg3  + ")" );
    
    if( sasDevKey.length == 0 )
    {
        PrintLog( 99, "Azure: SendCloudParamGet: SAS key not retrieved from cloud yet." );
        return;
    }
    
    
    // Clear the response so caller can wait...
    c2dParamGetData = null;
    
    // d2cMsg....................................
    i = FillD2cHeader( D2CMSG_PARAM_GET, true );

    u8AzureTxBuff[i++] = (myParam >> 0);                  // Get parameter
    u8AzureTxBuff[i++] = (myParam >> 8);
    u8AzureTxBuff[i++] = (myParam >> 16);
    u8AzureTxBuff[i++] = (myParam >> 24);
    
    var u8Temp = stringToBytes(myStrArg1);
    u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
    u8AzureTxBuff[i++] = (u8Temp.length >> 8);
    
    for( j = 0; j < u8Temp.length; j++ )
    {
        u8AzureTxBuff[i++] = u8Temp[j];
    }
    
    u8Temp = stringToBytes(myStrArg2);
    u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
    u8AzureTxBuff[i++] = (u8Temp.length >> 8);
    
    for( j = 0; j < u8Temp.length; j++ )
    {
        u8AzureTxBuff[i++] = u8Temp[j];
    }

    u8Temp = stringToBytes(myStrArg3);
    u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
    u8AzureTxBuff[i++] = (u8Temp.length >> 8);
    
    for( j = 0; j < u8Temp.length; j++ )
    {
        u8AzureTxBuff[i++] = u8Temp[j];
    }
    
    var payloadSize = i - d2cHeaderLen;                 // Current number of bytes minus 16-byte header.
    u8AzureTxBuff[4] = (payloadSize >> 0);              // payloadSize in bytes
    u8AzureTxBuff[5] = (payloadSize >> 8);
    u8AzureTxBuff[6] = (payloadSize >> 16);
    u8AzureTxBuff[7] = (payloadSize >> 24);
    
    GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
        
    var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/events?api-version=" + platformVer;
    var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };

     SendNorthBoundDataBinary( 
        "POST",
        myDataUrl,
        "application/octet-stream",
        u8AzureTxBuff,
        i,                              // length
        "",                             // response format
        myHeader,
        function(response) 
        {
            PrintLog( 1, "Azure: Response success: SendCloudParamGet()..."  );        
        },
        function(response) 
        {
            PrintLog( 99, "Azure: Response error: SendCloudParamGet()..." + JSON.stringify(response) );
        }
    );
}


// SendCloudParamSet............................................................................................
//
//  This function is used to set a non-tech-mode parameter value in the cloud.
//  
//  enum PARAMTYPES
//  {
//      WAVE2_PARAMTYPE_FIRSTNAME               = 1,
//      WAVE2_PARAMTYPE_OPERATORLIST,
//      WAVE2_PARAMTYPE_SKU
//  };
//  
//  typedef struct
//  {
//    E32(PARAMTYPES)         param;
//    varstr                  value;
//    varstr                  optarg1;
//    varstr                  optarg2;
//    varstr                  optarg3;
//  } d2cMsg_Param_Set;                             //Reference: D2CMSG_PARAM_SET
//
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  
//  typedef struct
//  {
//      d2cMsgHdr               hdr;            // No payload associated with this message.
//  } d2cMsg;
//
function SendCloudParamSet(myParam, myStrValue, myStrArg1, myStrArg2, myStrArg3)
{
    var i              = 0;
    
    PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudParamSet(" + paramTypeStr[myParam] + ", " + myStrValue +  ", arg1=" + myStrArg1 + ", arg2=" + myStrArg2 + ", arg3=" + myStrArg3 + ")" );
    
    if( sasDevKey.length == 0 )
    {
        PrintLog( 99, "Azure: SendCloudParamSet: SAS key not retrieved from cloud yet." );
        return;
    }
    
    // d2cMsg....................................
    i = FillD2cHeader( D2CMSG_PARAM_SET, true );

    u8AzureTxBuff[i++] = (myParam >> 0);                  // Set parameter
    u8AzureTxBuff[i++] = (myParam >> 8);
    u8AzureTxBuff[i++] = (myParam >> 16);
    u8AzureTxBuff[i++] = (myParam >> 24);
    
    var u8Temp = stringToBytes(myStrValue);
    u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
    u8AzureTxBuff[i++] = (u8Temp.length >> 8);
    
    for( j = 0; j < u8Temp.length; j++ )
    {
        u8AzureTxBuff[i++] = u8Temp[j];
    }


    u8Temp = stringToBytes(myStrArg1);
    u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
    u8AzureTxBuff[i++] = (u8Temp.length >> 8);
    
    for( j = 0; j < u8Temp.length; j++ )
    {
        u8AzureTxBuff[i++] = u8Temp[j];
    }
    
    u8Temp = stringToBytes(myStrArg2);
    u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
    u8AzureTxBuff[i++] = (u8Temp.length >> 8);
    
    for( j = 0; j < u8Temp.length; j++ )
    {
        u8AzureTxBuff[i++] = u8Temp[j];
    }

    u8Temp = stringToBytes(myStrArg3);
    u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
    u8AzureTxBuff[i++] = (u8Temp.length >> 8);
    
    for( j = 0; j < u8Temp.length; j++ )
    {
        u8AzureTxBuff[i++] = u8Temp[j];
    }




    var payloadSize = i - d2cHeaderLen;                 // Current number of bytes minus 16-byte header.
    u8AzureTxBuff[4] = (payloadSize >> 0);              // payloadSize in bytes
    u8AzureTxBuff[5] = (payloadSize >> 8);
    u8AzureTxBuff[6] = (payloadSize >> 16);
    u8AzureTxBuff[7] = (payloadSize >> 24);
    
    
    GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
        
    var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/events?api-version=" + platformVer;
    var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };

     SendNorthBoundDataBinary( 
        "POST",
        myDataUrl,
        "application/octet-stream",
        u8AzureTxBuff,
        i,                              // length
        "",                             // response format
        myHeader,
        function(response) 
        {
            PrintLog( 1, "Azure: Response success: SendCloudParamSet()..."  );        
        },
        function(response) 
        {
            PrintLog( 99, "Azure: Response error: SendCloudParamSet()..." + JSON.stringify(response) );
        }
    );
}





// SendCloudCheckSwUpdate............................................................................................
//
//  This function is used to send all SW image versions to the cloud for comparasion.   If any are out of date
//  then the poll message will pick up.
//   
//   Image   enum    Part Number             File Name
//   NU        1     700N036-XXX-YYY         WuExecutable.sec
//   CU        2     700N036-XXX-YYY         CuExecutable.sec
//   NU_PIC    3     700N040-00X-0YY         NuPICFlashImg.bin
//   CU_PIC    4     700N040-00X-0YY         CuPICFlashImg.bin
//   NU_BT     5     700N041-0XX-0YY         NuBTFlashImg.bin   (Not applicable for Wave App)
//   CU_BT     6     700N041-0XX-0YY         CuBTFlashImg.bin
//   NU_ART    7     800N003-XXX-YYY         NuBmpFlash.bin
//   CU_ART    8     800N003-XXX-YYY         CuBmpFlash.bin
//   NU_EVM    9     800N004-XXX-YYY         NuEvm.bin
//   CU_EVM   10     800N004-XXX-YYY         CuEvm.bin
//   NU_SCFG  11     700N037-XXXX-YY         NuSCfg.bin
//   NU_UCFG  12     700N037-XXXX-YY         NuUCfg.bin
//
//
//  typedef struct
//  {
//    E8(IMAGETYPES)          imagetype;
//    varstr                  version;            //Example: "700N036-002-023"
//  } swImageCurrentType;
//  
//  typedef struct
//  {
//    unsigned int            numImages;
//    swImageCurrentType      images[1];          //variable size field as determined by numImages
//  } d2cMsg_SwUpdate;                              //Reference: D2CMSG_SWUPDATE
//
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  
//  typedef struct
//  {
//      d2cMsgHdr               hdr;
//      unsigned int            payload[1];     //variable-size field as determined by hdr.type
//  } d2cMsg;
//  
function SendCloudCheckSwUpdate()
{
    var i              = 0;
    var j              = 0;
    var k              = 0;
    var iNum           = 0;
    
    PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudCheckSwUpdate()" );
    
    if( sasDevKey.length == 0 )
    {
        PrintLog( 99, "Azure: SendCloudCheckSwUpdate: SAS key not retrieved from cloud yet." );
        return;
    }
    
    
    var pnNu        = null;
    var pnCu        = null;
    var pnNuPic     = null;
    var pnCuPic     = null;
    var pnNuBt      = null;
    var pnCuBt      = null;
    var pnNuArt     = null;
    var pnCuArt     = null;
    var pnNuEvm     = null;
    var pnCuEvm     = null;
    var pnNuScfg    = null;
    var pnNuUcfg    = null;
    

// Testing...........................
// nxtySwVerNuCf  = "0.22";
// nxtySwVerCuCf  = "0.22";
// nxtySwVerNuPic = "0.0";
// nxtySwVerCuPic = "0.0";
// nxtySwVerNuArt = "0.0";
// nxtySwVerCuArt = "019.001";
// nxtySwVerNuSCfg = nxtySwVerNuUCfg = nxtyConfigPn = "0.0";
// nxtySwVerCuEvm   = "0.0";
// Testing...........................
    
    if( nxtySwVerNuCf   != null)  pnNu     = SwPnNuCu  + nxtySwVerNuCf.replace(".", "-");
    if( nxtySwVerCuCf   != null)  pnCu     = SwPnNuCu  + nxtySwVerCuCf.replace(".", "-"); 
    if( nxtySwVerNuPic  != null)  pnNuPic  = SwPnPic   + nxtySwVerNuPic.replace(".", "-");
    if( nxtySwVerCuPic  != null)  pnCuPic  = SwPnPic   + nxtySwVerCuPic.replace(".", "-");
    if( nxtySwVerCuBt   != null)  pnCuBt   = SwPnBt    + nxtySwVerCuBt.replace(".", "-");
    if( nxtySwVerNuArt  != null)  pnNuArt  = SwPnArt   + nxtySwVerNuArt.replace(".", "-");
    if( nxtySwVerCuArt  != null)  pnCuArt  = SwPnArt   + nxtySwVerCuArt.replace(".", "-");
    if( nxtySwVerNuEvm  != null)  pnNuEvm  = SwPnEvm   + nxtySwVerNuEvm.replace(".", "-");
    if( nxtySwVerCuEvm  != null)  pnCuEvm  = SwPnEvm   + nxtySwVerCuEvm.replace(".", "-");
    if( nxtySwVerNuSCfg != null)  pnNuScfg = nxtyConfigPn; 
    if( nxtySwVerNuUCfg != null)  pnNuUcfg = nxtyConfigPn; 


    
    
    // d2cMsg....................................
    i = FillD2cHeader( D2CMDG_SWUPDATE, true );


    var imgType  = [WAVE2_IMAGETYPE_NU, WAVE2_IMAGETYPE_CU, WAVE2_IMAGETYPE_NU_PIC, WAVE2_IMAGETYPE_CU_PIC, WAVE2_IMAGETYPE_CU_BT, WAVE2_IMAGETYPE_NU_ART, WAVE2_IMAGETYPE_CU_ART, WAVE2_IMAGETYPE_NU_EVM, WAVE2_IMAGETYPE_CU_EVM, WAVE2_IMAGETYPE_NU_SCFG, WAVE2_IMAGETYPE_NU_UCFG];   
    var imgPn    = [pnNu,               pnCu,               pnNuPic,                pnCuPic,                pnCuBt,                pnNuArt,                pnCuArt,                pnNuEvm,                pnCuEvm,                pnNuScfg,                pnNuUcfg];

    // payload  d2cMsg_SwUpdate
    u8AzureTxBuff[i++] = imgType.length;              // numImages.            
    u8AzureTxBuff[i++] = 0;              
    u8AzureTxBuff[i++] = 0;              
    u8AzureTxBuff[i++] = 0;              

    for( k = 0; k < imgType.length; k++ )
    {        
        // Only send if there is data...
        if( imgPn[k] != null )
        {
            iNum++;
            
            u8AzureTxBuff[i++] = imgType[k];
          
            var u8Temp = stringToBytes(imgPn[k]);
            u8AzureTxBuff[i++] = (u8Temp.length >> 0);         // Add the 2 byte length
            u8AzureTxBuff[i++] = (u8Temp.length >> 8);
            for( j = 0; j < u8Temp.length; j++ )
            {
                u8AzureTxBuff[i++] = u8Temp[j];
            }
            
            PrintLog(1, "  " + imageTypeStr[ imgType[k] ] + ":" + imgPn[k] );
        }
    }
  
    // Reset the number...
    u8AzureTxBuff[16] = iNum;              // numImages.            

    
    // Fill in the payload size...........
    var payloadSize = i - d2cHeaderLen;             // Current number of bytes minus 16-byte header.
    u8AzureTxBuff[4] = (payloadSize >> 0);          // payloadSize in bytes
    u8AzureTxBuff[5] = (payloadSize >> 8);
    u8AzureTxBuff[6] = (payloadSize >> 16);
    u8AzureTxBuff[7] = (payloadSize >> 24);

    GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
        
    var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/events?api-version=" + platformVer;
    var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };
   

     SendNorthBoundDataBinary( 
        "POST",
        myDataUrl,
        "application/octet-stream",
        u8AzureTxBuff,
        i,                              // length
        "",                             // response format
        myHeader,
        function(response) 
        {
            PrintLog( 1, "Azure: Response success: SendCloudCheckSwUpdate()..."  ); 
            s_CheckSwUpdateCount = 0;       
        },
        function(response) 
        {
            PrintLog( 99, "Azure: Response error: SendCloudCheckSwUpdate()..." + JSON.stringify(response) );
            
            if( s_CheckSwUpdateCount < 3 )
            {
                // Retry...
                PrintLog( 1, "Retrying SendCloudCheckSwUpdate()" );
                setTimeout( function(){ SendCloudCheckSwUpdate(); }, 100 );  // New thread in 100 mS.
                s_CheckSwUpdateCount++;
            }
            
        }
    );
}


// SendCloudTechPeriodDebug............................................................................................
//
//  This function is used to trigger tech data debug message.
//
//  typedef struct
//  {
//      unsigned char           version;
//      E8(D2CMSGTYPE)          type;
//      unsigned char           reserved[2];
//      unsigned int            payloadSize;
//      long long               uniqueID;
//  } d2cMsgHdr;
//  
//  typedef struct
//  {
//      d2cMsgHdr               hdr;            // No payload associated with this message.
//  } d2cMsg;
//
function SendCloudTechPeriodDebug()
{
    var i              = 0;
    
    PrintLog(1,  "Azure: id:" + iMsgId + " SendCloudTechPeriodDebug()" );
    
    if( sasDevKey.length == 0 )
    {
        PrintLog( 99, "Azure: SendCloudTechPeriodDebug: SAS key not retrieved from cloud yet." );
        return;
    }
    
    // d2cMsg....................................
    i = FillD2cHeader( D2CMSG_DEBUG_TECHDATASETPERIOD, true );

    GenerateSasDevTokenHourly( "/devices/" + azureDeviceId );
        
    var myDataUrl = "https://" + platformName + "/devices/" + azureDeviceId + "/messages/events?api-version=" + platformVer;
    var myHeader  =  {"Authorization":sasDevToken, "iothub-messageid":iMsgId++ };
   

     SendNorthBoundDataBinary( 
        "POST",
        myDataUrl,
        "application/octet-stream",
        u8AzureTxBuff,
        i,                              // length
        "",                             // response format
        myHeader,
        function(response) 
        {
            PrintLog( 1, "Azure: Response success: SendCloudTechPeriodDebug()..."  );        
        },
        function(response) 
        {
            PrintLog( 99, "Azure: Response error: SendCloudTechPeriodDebug()..." + JSON.stringify(response) );
        }
    );
}


























// RetrieveCloudDeviceKey............................................................................................
//   First see if device exists by sending a "GET":  
//     Example: https://NextivityIoTHubDev.azure-devices.net/devices/1118B37326C26CAA?api-version=2015-08-15-preview
//     if successful then the primary key returned will contain the key for the device.
//     if not successful, check the return statusText and if it is "Not Found" then go register the device.
//
function RetrieveCloudDeviceKey()
{
    if( azureDeviceId.length )
    {
        var myDataUrl   = "https://" + platformName + "/devices/" + azureDeviceId + "?api-version=" + platformVer;
        var myData      = "";
        var sasHubToken = GetSasHubToken( "/devices/" + azureDeviceId );
        var myHeader    =  {"Authorization":sasHubToken};
        
        PrintLog( 1, "Azure: RetrieveCloudDeviceKey: " + myDataUrl );
        
        SendNorthBoundData( 
            "GET",
            myDataUrl,
            "application/json",
            myData,
            "",                             // response format
            myHeader,
            function(response) 
            {
                if( response != null )
                {
                    var responseText = JSON.stringify(response);    // Returns "" at a minimum
                    if( responseText.length > 2 )
                    {
                        PrintLog( 1, "Azure: Response success: RetrieveCloudDeviceKey()..." );
                        sasDevKey = response.authentication.symmetricKey.primaryKey;
                        
                        if( regIotFlag == "U" )
                        {
                            // Prime the SQL database for this unit...
                            SendCloudAssociateSystem();
                            SendCloudAssociateBoards();
                        }
                        
                        StartCloudPoll( 1000 );             // Start a 1 second poll to flush the C2D queue.
                    }
                }
            },
            function(response) 
            {
                if( response.statusText == "Not Found" )
                {
                    // Try to create the ID...
                    PrintLog( 1, "Azure: Device has not been created yet so go and create..." );
                    CreateCloudDeviceKey(azureDeviceId);
                }
                else
                {
                    PrintLog( 99, "Azure: Response error: RetrieveCloudDeviceKey()..." + JSON.stringify(response) );
                }
            }
        );

    }
    else
    {
        PrintLog( 99, "Azure: RetrieveCloudDeviceKey: Device ID, i.e. CU Unique ID, not available yet." );
    }
}


// CreateCloudDeviceKey............................................................................................
//   Create the device in Azure with a "PUT"...  
//     Example: https://NextivityIoTHubDev.azure-devices.net/devices/1118B37326C26CAA?api-version=2015-08-15-preview
//
function CreateCloudDeviceKey(myId)
{
    if( azureDeviceId.length )
    {
        var myDataUrl   = "https://" + platformName + "/devices/" + myId + "?api-version=" + platformVer;
        var myData      = "{'deviceId':'" + myId + "'}";
        var sasHubToken = GetSasHubToken( "/devices/" + myId );
        var myHeader    =  {"Authorization":sasHubToken};
        
        PrintLog( 1, "Azure: CreateCloudDeviceKey: " + myDataUrl + " " + myData );
        
        SendNorthBoundData( 
            "PUT",
            myDataUrl,
            "application/json",
            myData,
            "",                             // response format
            myHeader,
            function(response) 
            {
                if( response != null )
                {
                    var responseText = JSON.stringify(response);    // Returns "" at a minimum
                    if( responseText.length > 2 )
                    {
                        PrintLog( 1, "Azure: Response success: CreateCloudDeviceKey()..." );
                        sasDevKey = response.authentication.symmetricKey.primaryKey;
                        
                        // Prime the SQL database for this unit...
                        SendCloudAssociateSystem();
                        SendCloudAssociateBoards();
                        StartCloudPoll( 1000 );             // Start a 1 second poll to flush the C2D queue.
                    }
                }
            },
            function(response) 
            {
                PrintLog( 99, "Azure: Response error: CreateCloudDeviceKey()..." + JSON.stringify(response) );
            }
        );

    }
    else
    {
        PrintLog( 99, "Azure: CreateCloudDeviceKey: Device ID, i.e. CU Unique ID, not available yet." );
    }
}


// ----------------------------------------------------------------------------------------------
// Generate a Device token with a 2 hour expiration.  
// Regenerate the token every hour.
var tokenTimeSec = 0;        // Last time the token was generated.
function GenerateSasDevTokenHourly(entityPath) 
{
    var ds    = new Date();
    var dsSec = (ds.getTime() / 1000);
    
    if( (tokenTimeSec - dsSec) < (1 * 3600) )
    {
        sasDevToken = GetSasDevToken( entityPath );
        PrintLog(1, "Azure: Regenerate 2 hour SAS token:" + sasDevToken );    
    }
}


// ----------------------------------------------------------------------------------------------
function GetSasDevToken(entityPath) 
{ 
    var uri = platformName + entityPath; 

    var ds   = new Date();
    var expireInSeconds = Math.round((ds.getTime() / 1000) + (2 * 3600));
    tokenTimeSec = expireInSeconds;

    var toBeHashed = utf8Encode(uri + "\n" + expireInSeconds); 
    var decodedKey = CryptoJS.enc.Base64.parse(sasDevKey);

    var hash = CryptoJS.HmacSHA256(toBeHashed, decodedKey); 
    var base64HashValue = CryptoJS.enc.Base64.stringify(hash); 

    var token = "SharedAccessSignature sr=" + uri + "&sig=" + 
        encodeURIComponent(base64HashValue) + "&se=" + expireInSeconds + "&skn=" + sasDevKeyName; 

    return token; 
} 

// ----------------------------------------------------------------------------------------------
function GetSasHubToken(entityPath) 
{ 
    var uri = platformName + entityPath; 

    var ds   = new Date();
    var expireInSeconds = Math.round((ds.getTime() / 1000) + (60 * 2));

    var toBeHashed = utf8Encode(uri + "\n" + expireInSeconds); 
    var decodedKey = CryptoJS.enc.Base64.parse(sasHubKey);

    var hash = CryptoJS.HmacSHA256(toBeHashed, decodedKey); 
    var base64HashValue = CryptoJS.enc.Base64.stringify(hash); 

    var token = "SharedAccessSignature sr=" + uri + "&sig=" + 
        encodeURIComponent(base64HashValue) + "&se=" + expireInSeconds + "&skn=" + sasHubKeyName; 

    return token; 
} 

// ----------------------------------------------------------------------------------------------
function utf8Encode(s)
{ 
    for(var c, i = -1, l = (s = s.split("")).length, o = String.fromCharCode; ++i < l;
            s[i] = (c = s[i].charCodeAt(0)) >= 127 ? o(0xc0 | (c >>> 6)) + o(0x80 | (c & 0x3f)) : s[i]
        );
    return s.join("");    
} 










// ----------------------------------------------------------------------------------------------
const   techMeasIds =
{
    // TNRx_...
    "Band":                 0,      // MEASID_TNRA_Band = 0,
    "LTE?":                 1,      // MEASID_TNRA_RAT,
    "Bandwidth":            2,      // MEASID_TNRA_Bandwidth,
    "DL Center Freq":       3,      // MEASID_TNRA_DL_Center_Freq,
    "UL Center Freq":       4,      // MEASID_TNRA_UL_Center_Freq,
//    "DL RSSI":              5,      // MEASID_TNRA_LTE_DL_RSSI,
    "DL RSSI":              6,      // MEASID_TNRA_3G_DL_RSSI,
//    "Max DL RSCP":          7,      // MEASID_TNRA_Max_DL_LTE_RSRP,
//    "Max DL ECIO":          8,      // MEASID_TNRA_Max_DL_LTE_RSRQ,
    "Max DL RSCP":          9,      // MEASID_TNRA_Max_DL_3G_RSCP,
    "Max DL ECIO":          10,     // MEASID_TNRA_Max_DL_3G_ECIO,
    "Remote Shutdown":      11,     // MEASID_TNRA_Remote_Shutdown,
    "Narrow Filter In Use": 12,     // MEASID_TNRA_Narrow_Filter_In_Use,
    "Ext Ant In Use":       13,     // MEASID_TNRA_Ext_Ant_In_Use,
    "UL Safe Mode Gain":    14,     // MEASID_TNRA_UL_Safe_Mode_Gain,
    "Relaying":             15,     // MEASID_TNRA_Relaying,
    "Cell Count":           16,     // MEASID_TNRA_Cell_Count,
//    "28 0":                 17,     // MEASID_TNRA_LTE_CellID28Bit,
    "28 0":                 18,     // MEASID_TNRA_3G_CellID28Bit0,
    "28 1":                 19,     // MEASID_TNRA_3G_CellID28Bit1,
    "28 2":                 20,     // MEASID_TNRA_3G_CellID28Bit2,
    "28 3":                 21,     // MEASID_TNRA_3G_CellID28Bit3,
    "28 4":                 22,     // MEASID_TNRA_3G_CellID28Bit4,
//    "Lte ID":               23,     // MEASID_TNRA_LTE_PCI,
    "ID0":                  24,     // MEASID_TNRA_3G_PSC0,
    "ID1":                  25,     // MEASID_TNRA_3G_PSC1,
    "ID2":                  26,     // MEASID_TNRA_3G_PSC2,
    "ID3":                  27,     // MEASID_TNRA_3G_PSC3,
    "ID4":                  28,     // MEASID_TNRA_3G_PSC4,
//    "RSRP":                 29,     // MEASID_TNRA_LTE_RSRP,
    "RSCP 0":               30,     // MEASID_TNRA_3G_RSCP0,
    "RSCP 1":               31,     // MEASID_TNRA_3G_RSCP1,
    "RSCP 2":               32,     // MEASID_TNRA_3G_RSCP2,
    "RSCP 3":               33,     // MEASID_TNRA_3G_RSCP3,
    "RSCP 4":               34,     // MEASID_TNRA_3G_RSCP4,
//    "RSRQ":                 35,     // MEASID_TNRA_LTE_RSRQ,
    "ECIO 0":               36,     // MEASID_TNRA_3G_ECIO0,
    "ECIO 1":               37,     // MEASID_TNRA_3G_ECIO1,
    "ECIO 2":               38,     // MEASID_TNRA_3G_ECIO2,
    "ECIO 3":               39,     // MEASID_TNRA_3G_ECIO3,
    "ECIO 4":               40,     // MEASID_TNRA_3G_ECIO4,
//    "SINR":                 41,     // MEASID_TNRA_LTE_SINR,
//    "Freq Err Res":         42,     // MEASID_TNRA_Freq_Err_Res,
//    "Freq Err Tot":         43,     // MEASID_TNRA_Freq_Err_Tot,
//    "MP Early":             44,     // MEASID_TNRA_MP_Early,
//    "MP Late":              45,     // MEASID_TNRA_MP_Late,
//    "MP Margin":            46,     // MEASID_TNRA_MP_Margin,
//    "CFI BER":              47,     // MEASID_TNRA_CFI_BER,
//    "SIB 1 Cnt":            48,     // MEASID_TNRA_SIB1_Cnt,
//    "SIB 2 Cnt":            49,     // MEASID_TNRA_SIB2_Cnt,            (not used)
//    "DCI":                  50,     // MEASID_TNRA_DCI,
//    "HARQ Comb":            51,     // MEASID_TNRA_HARQ_Comb,
//    "Lte Ant":              52,     // MEASID_TNRA_LTE_Ant,
    "DL Freq 0":            53,     // MEASID_TNRA_3G_DL_FREQ0,
    "DL Freq 1":            54,     // MEASID_TNRA_3G_DL_FREQ1,
    "DL Freq 2":            55,     // MEASID_TNRA_3G_DL_FREQ2,
    "DL Freq 3":            56,     // MEASID_TNRA_3G_DL_FREQ3,
    "DL Freq 4":            57,     // MEASID_TNRA_3G_DL_FREQ4,
//    "PLMN00":               58,     // MEASID_TNRA_LTE_PLMN0,
//    "PLMN01":               59,     // MEASID_TNRA_LTE_PLMN1,
//    "PLMN02":               60,     // MEASID_TNRA_LTE_PLMN2,
//    "PLMN03":               61,     // MEASID_TNRA_LTE_PLMN3,
//    "PLMN04":               62,     // MEASID_TNRA_LTE_PLMN4,
//    "PLMN05":               63,     // MEASID_TNRA_LTE_PLMN5,
    
    "PLMN00":               64,     // MEASID_TNRA_3G_PLMN00,
    "PLMN01":               65,     // MEASID_TNRA_3G_PLMN01,
    "PLMN02":               66,     // MEASID_TNRA_3G_PLMN02,
    "PLMN03":               67,     // MEASID_TNRA_3G_PLMN03,
    "PLMN04":               68,     // MEASID_TNRA_3G_PLMN04,
    "PLMN05":               69,     // MEASID_TNRA_3G_PLMN05,

    "PLMN10":               70,     // MEASID_TNRA_3G_PLMN10,
    "PLMN11":               71,     // MEASID_TNRA_3G_PLMN11,
    "PLMN12":               72,     // MEASID_TNRA_3G_PLMN12,
    "PLMN13":               73,     // MEASID_TNRA_3G_PLMN13,
    "PLMN14":               74,     // MEASID_TNRA_3G_PLMN14,
    "PLMN15":               75,     // MEASID_TNRA_3G_PLMN15,
    
    "PLMN20":               76,     // MEASID_TNRA_3G_PLMN20,
    "PLMN21":               77,     // MEASID_TNRA_3G_PLMN21,
    "PLMN22":               78,     // MEASID_TNRA_3G_PLMN22,
    "PLMN23":               79,     // MEASID_TNRA_3G_PLMN23,
    "PLMN24":               80,     // MEASID_TNRA_3G_PLMN24,
    "PLMN25":               81,     // MEASID_TNRA_3G_PLMN25,

    "PLMN30":               82,     // MEASID_TNRA_3G_PLMN30,
    "PLMN31":               83,     // MEASID_TNRA_3G_PLMN31,
    "PLMN32":               84,     // MEASID_TNRA_3G_PLMN32,
    "PLMN33":               85,     // MEASID_TNRA_3G_PLMN33,
    "PLMN34":               86,     // MEASID_TNRA_3G_PLMN34,
    "PLMN35":               87,     // MEASID_TNRA_3G_PLMN35,

    "PLMN40":               88,     // MEASID_TNRA_3G_PLMN40,
    "PLMN41":               89,     // MEASID_TNRA_3G_PLMN41,
    "PLMN42":               90,     // MEASID_TNRA_3G_PLMN42,
    "PLMN43":               91,     // MEASID_TNRA_3G_PLMN43,
    "PLMN44":               92,     // MEASID_TNRA_3G_PLMN44,
    "PLMN45":               93,     // MEASID_TNRA_3G_PLMN45,
    
    "NU Temp":              33024,   // MEASID_TNM_Temp = 33024,

    // TC0Rx_
//    "UL RSSI":              768,     // MEASID_TCRA_LTE_UL_RSSI = 768,
    "UL RSSI":              769,     // MEASID_TCRA_3G_UL_RSSI,
    "DL Echo Gain":         770,     // MEASID_TCRA_DL_Echo_Gain,
    "UL Echo Gain":         771,     // MEASID_TCRA_UL_Echo_Gain,
    "DL Tx Power":          772,     // MEASID_TCRA_DL_TX_Power,
    "UL Tx Power":          773,     // MEASID_TCRA_UL_TX_Power,
    "CU Antenna":           774,     // MEASID_TCRA_Antenna,
    "DL System Gain":       775,     // MEASID_TCRA_DL_System_Gain,
    "UL System Gain":       776,     // MEASID_TCRA_UL_System_Gain,
    "CU Temp":              33152,   // MEASID_TCM_Temp = 33152,

    // TNM_...
    "NU 5G DL":             32768,   // MEASID_TNU_DL_Freq = 32768,
    "NU 5G UL":             32769,   // MEASID_TNU_UL_Freq,
    "NU UNII State":        32770,   // MEASID_TNU_UNII_State,
    "NU RSSI":              32771,   // MEASID_TNU_RSSI,
    "NU Tx Pwr":            32772,   // MEASID_TNU_Tx_Power,
    "NU Ctrl Chan BER":     32773,   // MEASID_TNU_Ctrl_Chan_BER,
    "Radar Detect Cnt":     32774,   // MEASID_TNU_Radar_Detect_Cnt,
    "NU Dist Metric":       32775,   // MEASID_TNU_Dist_Metric,
    "NU Bars":              32776,   // MEASID_TNU_Bars,
    "Booster Settings":     32781,   // MEASID_TNU_Booster_Settings (= 32781)
    "Booster BandA":        32782,   // MEASID_TNU_Booster_Settings_BandA (= 32782)
    "Booster BandB":        32783,   // MEASID_TNU_Booster_Settings_BandB (= 32783)
    "Booster BandC":        32784,   // MEASID_TNU_Booster_Settings_BandC (= 32784)
    
    "Small Cell Connected": 33025,   // MEASID_TNM_Small_Cell_Connected         
    "Registered":           33026,   // MEASID_TNM_System_Registered
    "NU ES Err":            33280,   // MEASID_TM_Error_Code_E1 = 33280,

    // TC0M_...
    "CU UNII State":        32896,   // MEASID_TCU_UNII_State = 32896,
    "CU RSSI":              32897,   // MEASID_TCU_RSSI,
    "CU Tx Pwr":            32898,   // MEASID_TCU_Tx_Power,
    "CU BER":               32899,   // MEASID_TCU_Ctrl_Chan_BER,
    "CU Metric":            32900,   // MEASID_TCU_Dist_Metric,
    "CU Bars":              32901,   // MEASID_TCU_Bars,



};


const   techMeasIdsLte =
{
    // TNRx_...
    "DL RSSI":              5,      // MEASID_TNRA_LTE_DL_RSSI,
    "Max DL RSCP":          7,      // MEASID_TNRA_Max_DL_LTE_RSRP,
    "Max DL ECIO":          8,      // MEASID_TNRA_Max_DL_LTE_RSRQ,
    "28 0":                 17,     // MEASID_TNRA_LTE_CellID28Bit,
    "Lte ID":               23,     // MEASID_TNRA_LTE_PCI,
    "RSRP":                 29,     // MEASID_TNRA_LTE_RSRP,
    "RSRQ":                 35,     // MEASID_TNRA_LTE_RSRQ,
    "SINR":                 41,     // MEASID_TNRA_LTE_SINR,
    "Freq Err Res":         42,     // MEASID_TNRA_Freq_Err_Res,
    "Freq Err Tot":         43,     // MEASID_TNRA_Freq_Err_Tot,
    "MP Early":             44,     // MEASID_TNRA_MP_Early,
    "MP Late":              45,     // MEASID_TNRA_MP_Late,
    "MP Margin":            46,     // MEASID_TNRA_MP_Margin,
    "CFI BER":              47,     // MEASID_TNRA_CFI_BER,
    "SIB 1 Cnt":            48,     // MEASID_TNRA_SIB1_Cnt,
    "SIB 2 Cnt":            49,     // MEASID_TNRA_SIB2_Cnt,            (not used)
    "DCI":                  50,     // MEASID_TNRA_DCI,
    "HARQ Comb":            51,     // MEASID_TNRA_HARQ_Comb,
    "Lte Ant":              52,     // MEASID_TNRA_LTE_Ant,

    "PLMN00":               58,     // MEASID_TNRA_LTE_PLMN0,
    "PLMN01":               59,     // MEASID_TNRA_LTE_PLMN1,
    "PLMN02":               60,     // MEASID_TNRA_LTE_PLMN2,
    "PLMN03":               61,     // MEASID_TNRA_LTE_PLMN3,
    "PLMN04":               62,     // MEASID_TNRA_LTE_PLMN4,
    "PLMN05":               63,     // MEASID_TNRA_LTE_PLMN5,
    
    // TC0Rx_
    "UL RSSI":              768,     // MEASID_TCRA_LTE_UL_RSSI = 768,

    // TNM_...

    // TC0M_...
};


// ----------------------------------------------------------------------------------------------
//   Match the data item text with the Azure measurement ID and return the ID.
//   Return -1 if not found.
//
function GetMeasId(dataItemText) 
{ 
    var measId      = -1;       // Set an error.
    var tempMeasId  = -1;
    var iRadio      = -1;       // Set to 0 to 3 if on a radio data item...
    
    // Separate the TNRx_ heading from the actual value
    var rawText = dataItemText.split("_");
    
    if( rawText.length == 2 )
    {
        var rawHead     = rawText[0];       // TNRx or TC0Rx or TNM TC0M 
        var rawDataItem = rawText[1];
        
        if( rawHead.substring(0,3) == "TNR" )
        {
            // We have an NU radio data item...
            iRadio = parseInt( rawHead.substring(3,4) );
        }
        else if( rawHead.substring(0,4) == "TC0R" )
        {
            // We have a CU radio data item...
            iRadio = parseInt( rawHead.substring(4,5) );
        }

        // Check to see if the data is radio, i.e. 0 to 3, based.
        if( (iRadio >= 0) && (iRadio <= 3) )
        {
            if( guiTechnologyTypes[iRadio] == 1 )
            {
                // LTE channel, Try the LTE array first...
                tempMeasId = techMeasIdsLte[rawDataItem];
                
                if( tempMeasId == undefined )
                {
                    // Try the non-LTE array
                    tempMeasId = techMeasIds[rawDataItem];
                }
            }
            else
            {
                // Use the non-LTE array
                tempMeasId = techMeasIds[rawDataItem];
            }
            
            // See if we found something...
            if( tempMeasId != undefined )
            {
                measId = tempMeasId;
                if( tempMeasId < 6000 )
                {
                    // Add the radio offset...  
                    // Items such as NU Temp(33024) and CU Temp (33152) do not get the radio offset. 
                    measId = tempMeasId + (iRadio * 1024);
                }
            }            
        }
        else
        {
            // Non-radio, just UNII or misc data.
            // Try the non-LTE array
            tempMeasId = techMeasIds[rawDataItem];
            
            // See if we found something...
            if( tempMeasId != undefined )
            {
                measId = tempMeasId;
            }            
            
        }
    
//        PrintLog(1, "GetMeasId(" + dataItemText + ") = " + measId );
    
    }
    else
    {
        PrintLog(99, "GetMeasId() format error:  Single underscore not found.  Text:" + dataItemText );
    }
    
    return( measId );
}



// ----------------------------------------------------------------------------------------------
//   Convert data values to a common format for Azure.
//     Input mPair[0] contains the data item and mPair[1] contains the data value.
//   - Convert True/Yes/Up to 1
//   - Convert False/No/Down to 0
//   - Convert all frequencies to 100KHz values
//   - All power, dB/dBm/Power, multiply by 8.
//
function StandardizeValues(mPair) 
{ 
    
    // Separate the TNRx_ heading from the actual tag
    var rawText = mPair[0].split("_");
    
    if( rawText.length == 2 )
    {
        var tag     = rawText[1];
        var tVal    = mPair[1];
        
        if( (tVal == "True") || (tVal == "Yes") || (tVal == "Up") )
        {
            mPair[1] = 1;
        }
        else if( (tVal == "False") || (tVal == "No") || (tVal == "Down") )
        {
            mPair[1] = 0;
        }
        
        // If tag contains "Freq" then the following are stored in MHz, need to convert to 100 KHz.
        //   - DL Center Freq
        //   - UL Center Freq
        //   - DL Freq 0 to DL Freq 4
        //   - Lte Freq
        //   - Freq Err Res (In units of Hz so do not use. Freq is at index 0)
        //   - Freq Err Tot (In units of Hz so do not use. Freq is at index 0)
        else if( (tag.indexOf("Freq") > 0) || (tag == "Bandwidth") )      // -1 no match, 0 indicates that Freq starts at index 0 which we do not want to adjust.
        {
            mPair[1] *= 10;     // Convert from MHz to 100 KHz, i.e. 874.0 --> 8740
        }
        
        else if( (tag.indexOf("NU 5G") >= 0) || (tag.indexOf("CU 5G") >= 0) )      
        {
            mPair[1] *= 10000;     // Convert from GHz to 100 KHz, i.e. 5.28 --> 52800
        }
        
        else if( (tag.indexOf("RSSI") >= 0) || (tag.indexOf("RSCP") >= 0) || (tag.indexOf("ECIO") >= 0)   || (tag.indexOf("Gain") >= 0) || 
                 (tag.indexOf("RSRP") >= 0) || (tag.indexOf("RSRQ") >= 0) || (tag.indexOf("Tx Pwr") >= 0) || (tag.indexOf("Tx Power") >= 0) )      // -1 no match
        {
            mPair[1] *= 8;     // Convert power to *8
        }
        
        
    }
    
    return(mPair);
}




// FixCloudVer....................................................................................
// 
// Convert version strings:   
//      700N036-017-022     to XXX.YYY
//      700N040-002-050     to XXX.YYY
//      700N041-003-001     to XXX.YYY
//      700N037-DHMV-01     to DHMV.YY
//      800N004-002-002     to XXX.YYY
//      800N003-003-001     to XXX.YYY
//
function FixCloudVer(ver)
{
    var inVer       = ver;
    var inVerDashed = ver.split("-");

    // First check to make sure that there are two dashes "-" in the string...
    if( inVerDashed.length == 3)
    {
        if( inVerDashed[0] == "700N037" )
        {
            //      700N037-DHMV-01     to DHMV.YY
            ver = inVerDashed[1].substring(0,4) + "." + inVerDashed[2].substring(inVerDashed[2].length-2); 
        }
        else
        {
            var str1 = inVerDashed[1];      // grab xxx
            var str2 = inVerDashed[2];      // grab yyy
            
            if( str1.length == 1 )                        // test for x.yyy
            {
                str1 = "00" + str1;
            }
            else if( str1.length == 2 )                   // test for xx.yyy
            {
                str1 = "0" + str1;
            }
            
            if( str2.length == 1 )                        // test for xxx.y
            {
                str2 = "00" + str2;
            }
            else if( str2.length == 2 )                   // test for xxx.yy
            {
                str2 = "0" + str2;
            }
            
            ver = str1 + "." + str2;
        }
        
        PrintLog(1, "    FixCloudVer() in =" + inVer + " out=" + ver );
        
    }
    else
    {
        ver = "000.000";
        PrintLog(99, "FixCloudVer() (2 dashes not found, force to 000.000) in =" + inVer + " out=" + ver );
    }    
    

    return( ver );
}

// FixInternalVer....................................................................................
// 
// Convert version strings, yyy.zzz to yyy.zzz making sure 7 characters...
//
function FixInternalVer(ver)
{
    var inVer = ver;

    // First check to make sure that there is a period "." in the string...
    if( ver.search(/\x2E/) != -1 )
    {
        // Make sure that it is zero loaded up front... xxx.yyy
        if( ver.length < 7 )
        {
            var str1 = ver.substring(0,ver.search(/\x2E/));         // grab xxx
            var str2 = ver.substring(ver.search(/\x2E/) + 1);       // grab yyy
            
            if( str1.length == 0 )                        // test for .yyy
            {
                str1 = "000";
            }
            else if( str1.length == 1 )                   // test for x.yyy
            {
                str1 = "00" + str1;
            }
            else if( str1.length == 2 )                   // test for xx.yyy
            {
                str1 = "0" + str1;
            }
            
            if( str2.length == 0 )                        // test for xxx.null
            {
                str2 = "000";
            }
            else if( str2.length == 1 )                   // test for xxx.y
            {
                str2 = "00" + str2;
            }
            else if( str2.length == 2 )                   // test for xxx.yy
            {
                str2 = "0" + str2;
            }
            
            ver = str1 + "." + str2;
        }
    }
    else
    {
        // No period so make something up...
        ver = "000.000";
    }    
    
//    PrintLog(1, "FixInternalVer() in =" + inVer + " out=" + ver );

    return( ver );
}


    

// ProcessSku............................................................................................
function ProcessSku(textIn)
{
    myModel = mySku = textIn;
    newOperatorSku  = mySku;         // Fill in as a default until user selects a new operator.
    guiProductType  = GetProductTypeFromSku( mySku );

    // If the 590 number power plug option is Auto, then this is mobility, per JC.
    // 590N P   3   4   FT  UK  1   VF  UK  6   B   B   1
    //                                      ^
    //                                   6 means Auto
    if( textIn.substring(16,17) == '6' )
    {
        guiMobilityFlag = true;
    }
    
    // The new 590 should be at least 20 characters in length...
    if( textIn.length >= 20 )
    {
        guiOperatorCode = textIn.substring(12,16);
        szRegCountry    = textIn.substring(14,16);  // Grab the operator 2-char country code.
    } 
    
    PrintLog(1, "SKU: " + mySku + "  Model Number: " + myModel + "  Product type based on SKU: " + guiProductType + " OpCode: " + guiOperatorCode );
}
    
    
    
    
    
// GetWssHubInfo.............................................................................................................
var WsIntervalHandle = null;
function GetWssHubInfo(uniqueId) 
{ 
//    var wsUri = "ws://echo.websocket.org/";           // Echo server
//    var wsUri = "wss://nextivitywsserver-qa.azurewebsites.net/WSChat/WSHandler.ashx?name=" + uniqueId;
//    var wsUri = "wss://nextivitywsserver-europe.azurewebsites.net/WSChat/WSHandler.ashx?name=" + uniqueId;
    var wsUri = "wss://iot.cel-fi.com/WSChat/WSHandler.ashx?name=" + uniqueId;
    
    
    PrintLog(1, "WS: GetWssHubInfo(" + uniqueId + ")");
     
    websocket = new WebSocket(wsUri); 
    websocket.onopen = function(evt) { onOpen(evt) }; 
    websocket.onclose = function(evt) { onClose(evt) }; 
    websocket.onmessage = function(evt) { onMessage(evt) }; 
    websocket.onerror = function(evt) { onError(evt) }; 
}  

function onOpen(evt) 
{ 
    PrintLog(1, "WS: Web Socket Opened and CONNECTED");
    
    if( WsIntervalHandle != null )
    {
        clearInterval(WsIntervalHandle)
        WsIntervalHandle = null;
    } 
}  

function onClose(evt) 
{ 
    PrintLog(1, "WS: DISCONNECTED - Try to reconnect every 10 seconds..."); 

    if( WsIntervalHandle == null )
    {
        WsIntervalHandle = setInterval( function(){ GetWssHubInfo(azureDeviceId); }, 10000 );       // Start a loop to try every 10 seconds.
        setTimeout( function(){ GetWssHubInfo(azureDeviceId); }, 10 );                              // Try immediately, i.e. 10 mS
    }
}  

function onMessage(evt) 
{ 
    // Per LB email 10/11/16, only check for strings...
    if( typeof evt.data === "string" )
    {
        PrintLog(1, "WS: Web socket RESPONSE stringify: " + JSON.stringify(evt.data) );
      
        if( evt.data == "C2D" )
        {
            PrintLog(1, "Azure: C2D Web socket poke, something is waiting in egress queue..." );
            
            // IOT Hub is telling us that there is data available so blast out a poll message to get it....
            iC2dCount++;
            StartCloudPoll(1000);
        }
        else
        {  
            // Data returned looks like: 
            // "nextivitystorageqa.blob.core.windows.net,NextivityIoTHubQA.azure-devices.net,R,MTomIRpfewofFUYxBjQzLAQhGBskKUIEBFAAMxUvMyMYGRVuCGIgFDtpGAA=,1118B37326C26CAA"
            var aData = evt.data.split(",");
            
            if( aData.length >= 4 )
            {
                blobPlatformName = aData[0];     
                platformName     = aData[1];
                regIotFlag       = aData[2];
                var tempKeyWords = CryptoJS.enc.Base64.parse(aData[3]);
                var tempKey      = CryptoJS.enc.Utf8.stringify(tempKeyWords);
                
                PrintLog(1, "WS: blob: " + blobPlatformName + " URL:" + platformName + " reg:" + regIotFlag );
                
                
                var keyBytes     = new Uint8Array(tempKey.length);
                var secBytes     = new Uint8Array(secretKey.length);
                var tempHubBytes = new Uint8Array(tempKey.length);
            
                if( tempKey.length == secretKey.length )
                {
                    for( var i = 0; i < tempKey.length; ++i ) 
                    {
                        keyBytes[i]  = tempKey.charCodeAt(i);
                        secBytes[i]  = secretKey.charCodeAt(i);
                        tempHubBytes[i] = keyBytes[i] ^ secBytes[i];
                        
    //                        PrintLog(1, "[" + i + "]: key: 0x" + keyBytes[i].toString(16) + " sec: 0x" + secBytes[i].toString(16) + " hub: 0x" + tempHubBytes[i].toString(16) );
                    }
                        
                    sasHubKey = bytesToString(tempHubBytes);
    //                    PrintLog(1, "WS: key: " + sasHubKey );
    
                    if( (sasDevKey.length == 0) && (platformName !== null) && (blobPlatformName !== null) && (sasHubKey !== null) && (regIotFlag !== null) )
                    {
                        RetrieveCloudDeviceKey();
                    }
    
                }
                else
                {
                    PrintLog(99, "WS: Key length mismatch: key length: " + tempKey.length + " secret key length: " + secretKey.length );
                }
            }
            else
            {
                PrintLog(99, "WS: Number of WS items should be >= 4, length: " + aData.length );
            }
        }
    }
    else
    {
        PrintLog(99, "WS: Non-string data returned..." );
    }
    
}  

function onError(evt) 
{ 
    PrintLog(99, "WS: ERROR: " + evt.data); 
}  
// End GetWssHubInfo..........................................................................................................
    
    
   